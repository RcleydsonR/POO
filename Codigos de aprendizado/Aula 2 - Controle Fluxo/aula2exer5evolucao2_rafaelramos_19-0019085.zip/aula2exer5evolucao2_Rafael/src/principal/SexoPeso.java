package principal;

import java.text.DecimalFormat;
import java.util.Locale;
import java.util.Scanner;

public class SexoPeso {
	public static void main(String[] args) {
		// DECLARACOES
		Locale.setDefault(Locale.US);
		Scanner ler = new Scanner(System.in);
		final int QTDPESSOAS = 20;
		String sexo;
		float peso, pesoMax = 0f, pesoMin = 0f, somaPesoMasc = 0f, media = 0f;
		int qtdFem = 0;

		// INSTRUCOES
		for (int i = 0; i < QTDPESSOAS; i++) {

			System.out.print("Digite o peso da " + (i + 1) + " pessoa: ");
			peso = ler.nextFloat();
			peso = validaPeso(peso, ler);

			System.out.println("Digite o sexo: (masculino ou feminino) da " + (i + 1) + " pessoa: ");
			sexo = ler.next();
			sexo = validaSexo(sexo, ler);

			if (i == 0) {
				pesoMin = peso;
				pesoMax = peso;
			}
			// PESO MAX E MIN
			
			pesoMin = menorPeso(pesoMin, peso);
			pesoMax = maiorPeso(pesoMax, peso);

			if (sexo.equalsIgnoreCase("masculino"))
				somaPesoMasc += peso;
			else
				qtdFem++;
		}

		if (qtdFem != QTDPESSOAS)
			media = somaPesoMasc / (QTDPESSOAS - qtdFem);
		
		// IMPRESSAO
		limpaTela();
		mostraDadosFinais(pesoMax, pesoMin, media, qtdFem);

	}

	public static float validaPeso(float peso, Scanner ler) {
		while (peso < 1 || peso > 999) {
			System.out.println("Peso invalido, digite um peso entre 1 e 999:");
			peso = ler.nextFloat();
		}
		return peso;
	}

	public static String validaSexo(String sexo, Scanner ler) {
		while (!sexo.equalsIgnoreCase("masculino") && !sexo.equalsIgnoreCase("feminino")) {
			System.out.println("Sexo lido invalido, digite masculino ou feminino");
			sexo = ler.next();
		}
		return sexo;
	}

	public static float menorPeso(float pesoMin, float peso) {
		return (peso < pesoMin) ? peso : pesoMin;
	}

	public static float maiorPeso(float pesoMax, float peso) {
		return (peso > pesoMax) ? peso : pesoMax;
	}

	public static void limpaTela() {
		for (int i = 0; i < 30; i++)
			System.out.println();
	}

	public static void mostraDadosFinais(float pesoMax, float pesoMin, float media, int qtdFem) {
		DecimalFormat mascara = new DecimalFormat("0.00");
		System.out.println("O maior e o menor peso informados foram, respectivamente: " + mascara.format(pesoMax) + " KG, " + mascara.format(pesoMin) + " KG");
		System.out.println("A media dos pesos dos homens e: " + mascara.format(media) + " KG");
		System.out.println("A quantidade de mulheres e: " + qtdFem);
	}
}
