package principal;

import java.text.DecimalFormat;
import java.util.Scanner;

public class OrdenaPeso {

	public static boolean validaPeso(float pesos[], int aux, int MIN) {
		if (pesos[aux] >= MIN)
			return true;
		else {
			System.out.println("Peso Invalido! Informe peso maior que " + MIN + ".");
			return false;
		}
	}

	public static float[] ordenaArray(float pesos[]) {
		for (int i = 1; i < pesos.length; i++) {
			float x = pesos[i];
			int j;
			for (j = i - 1; j >= 0 && pesos[j] > x; j--)
				pesos[j + 1] = pesos[j];
			pesos[j + 1] = x;
		}
		return pesos;
	}

	public static void limpaTela() {
		for (int aux = 0; aux < 7; aux++)
			System.out.println("\n");
	}

	public static void mostraArray(float pesos[], DecimalFormat mascara) {
		for (int aux = 0; aux < pesos.length; aux++)
			System.out.println("peso do elefante " + (aux + 1) + ": " + mascara.format(pesos[aux]));
	}

	public static void main(String[] args) {
		// DECLARACOES
		final int MAX = 3;
		final int PESOMINIMO = 5;
		DecimalFormat mascara = new DecimalFormat("0.00");
		float[] peso = new float[MAX];
		Scanner ler = new Scanner(System.in);

		// INSTRUCOES
		System.out.println("Informe o peso dos elefantes:");
		for (int contador = 0; contador < MAX; contador++) {
			System.out.println((contador + 1) + "� elefante:");
			peso[contador] = ler.nextFloat();
			while (validaPeso(peso, contador, PESOMINIMO) == false)
				peso[contador] = ler.nextFloat();
		}
		ordenaArray(peso);
		limpaTela();
		System.out.println("Pesos Gravados\n");
		mostraArray(peso, mascara);
		ler.close();
	}
}
