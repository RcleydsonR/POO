package principal;

import java.util.Scanner;

public class QntdVogal {

	public static void main(String[] args) {
		// Declaracoes
		String frase;
		char validade;
		int vogal[] = new int[6];
		Scanner ler = new Scanner(System.in);

		// Instrucoes
		do {
			System.out.println("Digite a frase: ");
			frase = ler.nextLine().trim();
			frase = validaFrase(frase, ler);

			limpaTela();
			limpaVogais(vogal);

			// Respostas

			contaVogais(frase, vogal);
			quantidadeVogais(frase, vogal);
			printInfos(frase, vogal);

			System.out.println("\n\nDeseja Continuar? Digite 's' para continuar ou 'n' para encerrar.");

			validade = ler.nextLine().toUpperCase().charAt(0);
			while (validade != 'S' && validade != 'N') {
				System.out.println("Digite apenas s/n.");
				validade = ler.nextLine().toUpperCase().charAt(0);
			}
		} while (validade == 'S');
		ler.close();

	}

	public static String validaFrase(String frase, Scanner ler) {
		while (frase.equals("")) {
			System.out.println("N�o h� dados na frase digitada, digite novamente:");
			frase = ler.nextLine().trim();
		}
		return frase;
	}

	public static void limpaVogais(int vogal[]) {
		for (int i = 0; i < 6; i++)
			vogal[i] = 0;
	}

	public static void limpaTela() {
		for (int aux = 0; aux < 25; aux++)
			System.out.println("\n");
	}

	public static void contaVogais(String frase, int vogal[]) {
		for (int tam = 0; tam < frase.length(); tam++) {
			if (frase.toUpperCase().charAt(tam) == 'A')
				vogal[0]++;
			if (frase.toUpperCase().charAt(tam) == 'E')
				vogal[1]++;
			if (frase.toUpperCase().charAt(tam) == 'I')
				vogal[2]++;
			if (frase.toUpperCase().charAt(tam) == 'O')
				vogal[3]++;
			if (frase.toUpperCase().charAt(tam) == 'U')
				vogal[4]++;
		}
	}

	public static void quantidadeVogais(String frase, int vogal[]) {
		int aux = 0;
		for (int tam = 0; tam < 5; tam++)
			vogal[5] += vogal[tam];
	}

	public static void printInfos(String frase, int vogal[]) {
		System.out.print("Quantidade de 'a': " + vogal[0] + "\nQuantidade de 'e': " + vogal[1] + "\nQuantidade de 'i': "
				+ vogal[2] + "\nQuantidade de 'o': " + vogal[3] + "\nQuantidade de 'u': " + vogal[4] + "\n");
		System.out.println("Quantidade total de vogais: " + vogal[5]);
		System.out.println("Tamanho da frase digitada: " + frase.length());

	}
}
