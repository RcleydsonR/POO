package principal;

import java.util.Scanner;

public class CadastroSenha {
	public static void main(String[] args) {
		final int MAXIMO = 9, TAM_MIN = 3, TAM_MAX = 5;
		String senha = "0", teste_senha;
		int i;
		Scanner ler = new Scanner(System.in);

		System.out.println(
				"Cadastre a senha desejada, s�o permitidas palavras de 3 a 5 caracteres nao podendo conter espaco em branco: ");
		senha = cadastraSenha(senha, TAM_MIN, TAM_MAX, ler);

		limpaTela(30);
		System.out.println("Seja bem-vindo. Digite a senha: ");
		for (i = 0; i < MAXIMO; i++) {
			teste_senha = ler.nextLine();
			if (validaSenha(teste_senha, senha) == false)
				System.out.println("Senha invalida. Restam " + (MAXIMO - i - 1) + " tentativas.");
			else {
				limpaTela(20);
				formataTela(28);
				System.out.println("Senha efetuada com sucesso.");
				break;
			}
		}
		if (i == MAXIMO) {
			System.out.println("O Sistema ir� fechar em 10 segundos.");
			encerraSistema(10000);
		}

	}

	public static String cadastraSenha(String senha, final int TAM_MIN, final int TAM_MAX, Scanner ler) {
		senha = ler.nextLine();
		while (senha.length() < TAM_MIN || senha.length() > TAM_MAX
				|| senha.replace(" ", "").length() != senha.length()) {
			System.out.println("Cadastro de senha invalido. Insira novamente: ");
			senha = ler.nextLine();
		}
		return senha;
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

	public static void formataTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.print(" ");
	}

	public static boolean validaSenha(String teste, String senha) {
		return (teste.equals(senha) ? true : false);
	}

	public static void encerraSistema(long timer_ms) {
		try {
			Thread.sleep(timer_ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
