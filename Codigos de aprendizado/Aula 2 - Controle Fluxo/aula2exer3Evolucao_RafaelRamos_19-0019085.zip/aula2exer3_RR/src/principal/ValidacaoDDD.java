package principal;

import java.util.Scanner;

public class ValidacaoDDD {

	public static void main(String[] args) {

		// Declara��es
		int DDD;
		Scanner ler = new Scanner(System.in);

		// Instru��es
		System.out.println("Digite um DDD valido: ");

		DDD = ler.nextInt();

		validarNum(DDD, ler);

		limpaTela();

		if (DDD == 61)
			System.out.println("DDD (61) pertence a Brasilia.");
		else if (DDD == 62)
			System.out.println("DDD (62) pertence a Goiania.");
		else if (DDD == 65)
			System.out.println("DDD (65) pertence a Cuiaba.");
		else if (DDD == 67)
			System.out.println("DDD (67) pertence a Campo Grande.");
		else
			System.out.println("DDD nao pertence a capital do centro-oeste brasileiro.");

		ler.close();
	}

	public static int validarNum(int num, Scanner ler) {
		while (num <= 10 || num >= 100) {
			System.out.println("DDD invalido, Informe novamente um DDD entre 11 e 99: ");
			num = ler.nextInt();
		}
		return num;
	}

	public static void limpaTela() {
		for (int i = 0; i < 30; i++)
			System.out.println("");
	}
}
