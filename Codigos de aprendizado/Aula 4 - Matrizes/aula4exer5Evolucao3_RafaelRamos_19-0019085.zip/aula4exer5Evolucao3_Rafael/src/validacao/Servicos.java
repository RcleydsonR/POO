package validacao;

import dados.Pessoa;

public class Servicos {

	public static StringBuilder primeiroNome(Pessoa pessoa) {

		// DECLARACAO
		int primeiroEspaco = 0;

		// INSTRUCOES
		do {
			primeiroEspaco++;
		} while (pessoa.getNome().charAt(primeiroEspaco) != ' ');

		StringBuilder primeiroNome = new StringBuilder(pessoa.getNome().toUpperCase());
		primeiroNome.delete(primeiroEspaco, pessoa.getNome().length());

		return primeiroNome;
	}

	public static StringBuilder ultimoNome(Pessoa pessoa) {

		// DECLARACAO
		int ultimoEspaco = pessoa.getNome().length();

		// INSTRUCOES
		do {
			ultimoEspaco--;
		} while (pessoa.getNome().charAt(ultimoEspaco) != ' ');

		StringBuilder ultimoNome = new StringBuilder(pessoa.getNome().toUpperCase());
		ultimoNome.delete(0, ultimoEspaco + 1);

		return ultimoNome;
	}


}
