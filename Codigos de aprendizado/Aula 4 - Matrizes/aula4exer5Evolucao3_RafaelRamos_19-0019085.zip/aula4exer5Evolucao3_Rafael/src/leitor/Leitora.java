package leitor;

import java.util.Scanner;

public class Leitora {

	// Leitura de uma string com espacos em branco
	public static String leituraLinha() {
		Scanner ler = new Scanner(System.in);
		return (ler.nextLine().trim());
	}

	public static char leituraChar() {
		Scanner ler = new Scanner(System.in);
		return (ler.next().trim().toUpperCase().charAt(0));
	}

}
