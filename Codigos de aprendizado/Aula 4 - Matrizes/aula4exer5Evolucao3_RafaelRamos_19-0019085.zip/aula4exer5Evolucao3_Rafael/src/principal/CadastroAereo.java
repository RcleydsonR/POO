package principal;

import dados.Pessoa;
import leitor.Leitora;
import validacao.Servicos;
import validacao.Validacao;
import saida.Saida;

public class CadastroAereo {

	public static void main(String[] args) {

		// INSTRUCOES
		do {
			Pessoa pessoa = new Pessoa(Validacao.validaNome());
			pessoa.setPrimeiroUltimoNome(Servicos.primeiroNome(pessoa), Servicos.ultimoNome(pessoa));
			Saida.mostraNome(pessoa);
		} while (Validacao.validaContinua());
	}
}
