package dados;

public class Pessoa {
	private String nome;
	private StringBuilder primeiroNome;
	private StringBuilder ultimoNome;

	public Pessoa(String nome) {
		setNome(nome);
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return this.nome;
	}

	public void setPrimeiroUltimoNome(StringBuilder primeiroNome, StringBuilder ultimoNome) {
		this.primeiroNome = primeiroNome;
		this.ultimoNome = ultimoNome;
	}

	public StringBuilder getPrimeiroNome() {
		return this.primeiroNome;
	}


	public StringBuilder getUltimoNome() {
		return this.ultimoNome;
	}
}
