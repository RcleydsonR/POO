package dados;

public class Grupo {

	private Vendedor [] vendedores;
	
	public Grupo(int qntdSemanas,final int QNTDVENDEDORES) {
		vendedores = new Vendedor[QNTDVENDEDORES];
		for ( int i = 0; i < QNTDVENDEDORES; i++)
			vendedores[i] = new Vendedor(qntdSemanas);
	}
	
	public Vendedor[] getVendedor() {
		return this.vendedores;
	}
}
