package dados;

public class Vendedor {

	private int [] vendaSemana;

	Vendedor(int Semanas) {
		this.vendaSemana = new int[Semanas];
	}

	public void setVendaSemanal(int vendaSemanal, int semana) {
		this.vendaSemana[semana] = vendaSemanal;
	}

	public int getVendaSemanal(int semana) {
		return this.vendaSemana[semana];
	}
}
