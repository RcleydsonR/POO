package leitor;

import java.util.Scanner;

public class Leitora {

	// Leitura de um inteiro
	public static int leituraInt() {
		Scanner ler = new Scanner(System.in);
		return ler.nextInt();
	}
}
