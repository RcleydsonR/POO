package saida;

public class Visao {
	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

	public static void solicitaSemana() {
		System.out.println("Digite a quantidade de semanas cont�beis deste m�s (3/4)");
	}

	public static void solicitaVenda(int numVendedor, int numSemana) {
		System.out.println(
				"Digite a quantidade de vendas do " + (numVendedor + 1) + "� vendedor na semana " + (numSemana + 1));
	}

	public static void alertaErroInt() {
		System.out.println("ERRO! O numero digitado deve ser inteiro");
	}

}
