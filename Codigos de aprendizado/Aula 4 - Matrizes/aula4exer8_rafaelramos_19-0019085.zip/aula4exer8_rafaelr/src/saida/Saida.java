package saida;

import dados.Vendedor;
import servicos.Servicos;
import servicos.Validacao;

public class Saida {

	public static void apresentaCabe�alho(int qntdSemanas) {
		// CABE�ALHO
		System.out.print("\tVENDEDOR\t|");
		for (int i = 1; i <= qntdSemanas; i++)
			System.out.print("\tSEMANA " + i + "\t|");
		System.out.println("\tMES\t|");
		for (int i = 0; i < (qntdSemanas * 36); i++)
			System.out.print("-");
		System.out.println();
	}

	public static void apresentaTabela(Vendedor vendedores[], int qntdSemanas) {
		// DECLARACOES
		int[] somaVendasSemanas = new int[qntdSemanas];
		int[] somaVendasMensais = new int[vendedores.length];
		int vendasTotal = 0;
		somaVendasSemanas = Servicos.somaVendasSemanas(vendedores, qntdSemanas);
		somaVendasMensais = Servicos.somaVendasMensais(vendedores, qntdSemanas);

		// INSTRUCOES
		Visao.limpaTela(50);
		apresentaCabe�alho(qntdSemanas);

		// CORPO

		for (int numVendedor = 0; numVendedor < vendedores.length; numVendedor++) {
			System.out.print("\t" + (numVendedor + 1) + "\t\t|");
			for (int numSemana = 0; numSemana < qntdSemanas; numSemana++)
				System.out.print("\t" + vendedores[numVendedor].getVendaSemanal(numSemana) + "\t\t|");
			System.out.println("\t" + somaVendasMensais[numVendedor] + "\t|");
			vendasTotal += somaVendasMensais[numVendedor];
		}

		for (int i = 0; i < (qntdSemanas * 36); i++)
			System.out.print("-");
		System.out.println();
		System.out.print("\tTOTAL\t\t|");
		for (int numSemana = 0; numSemana < qntdSemanas; numSemana++)
			System.out.print("\t" + somaVendasSemanas[numSemana] + "\t\t|");
		System.out.println("\t" + vendasTotal + "\t|");

	}

}
