package principal;

import dados.Grupo;
import saida.Saida;
import servicos.Servicos;
import servicos.Validacao;

public class Vendas {

	public static void main(String[] args) {
		final int QNTDVENDEDORES = 4;
		final int qntdSemanas = Validacao.validaSemana();
		Grupo grupo = new Grupo(qntdSemanas, QNTDVENDEDORES);
		Servicos.recebeVendas(grupo.getVendedor(), qntdSemanas);
		Saida.apresentaTabela(grupo.getVendedor(), qntdSemanas);
	}
}
