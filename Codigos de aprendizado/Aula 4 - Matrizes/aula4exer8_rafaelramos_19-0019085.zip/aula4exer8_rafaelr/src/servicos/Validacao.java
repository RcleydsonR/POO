package servicos;

import java.util.InputMismatchException;

import leitor.Leitora;
import saida.Saida;
import saida.Visao;

public class Validacao {

	// VALIDA INTEIROS
	public static int validaSemana() {
		// DECLARACOES
		boolean erro = false;
		int semana = 0;

		// INSTRUCOES
		do {
			Visao.solicitaSemana();
			try {
				semana = Leitora.leituraInt();
				if (semana < 3 || semana > 4) {
					Visao.limpaTela(1);
					System.out.println("Valor invalido!");
					Visao.limpaTela(1);
					erro = true;
				} else
					erro = false;
			} catch (InputMismatchException excecao) {
				Visao.limpaTela(1);
				Visao.alertaErroInt();
				Visao.limpaTela(1);
				erro = true;
			}
		} while (erro);
		return semana;
	}

	public static int validaVenda(int numVendedor, int numSemana) {
		// DECLARACOES
		boolean erro = false;
		int venda = 0;
		int valorMin = 0;

		// INSTRUCOES
		do {
			Visao.solicitaVenda(numVendedor, numSemana);
			try {
				venda = Leitora.leituraInt();
				if (venda < valorMin) {
					Visao.limpaTela(1);
					System.out.println("Valor invalido! Digite um numero maior que " + valorMin);
					erro = true;
					Visao.limpaTela(1);
				} else
					erro = false;
			} catch (InputMismatchException excecao) {
				Visao.limpaTela(1);
				Visao.alertaErroInt();
				Visao.limpaTela(1);
				erro = true;
			}
		} while (erro);
		return venda;
	}
}
