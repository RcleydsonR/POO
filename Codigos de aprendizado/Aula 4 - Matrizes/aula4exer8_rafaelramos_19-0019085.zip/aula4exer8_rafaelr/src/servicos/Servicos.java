package servicos;

import dados.Vendedor;

public class Servicos {

	public static void recebeVendas(Vendedor vendedores[], int qntdSemanas) {
		for (int numVendedor = 0; numVendedor < vendedores.length; numVendedor++) {
			for (int numSemana = 0; numSemana < qntdSemanas; numSemana++)
				vendedores[numVendedor].setVendaSemanal(Validacao.validaVenda(numVendedor, numSemana), numSemana);
		}
	}

	public static int[] somaVendasSemanas(Vendedor vendedores[], int qntdSemanas) {
		int[] somaVendasSemanas = new int[qntdSemanas];
		for (int numSemana = 0; numSemana < qntdSemanas; numSemana++)
			for (int numVendedor = 0; numVendedor < vendedores.length; numVendedor++) {
				somaVendasSemanas[numSemana] += vendedores[numVendedor].getVendaSemanal(numSemana);
			}
		return somaVendasSemanas;
	}

	public static int[] somaVendasMensais(Vendedor vendedores[], int qtdSemanas) {
		int[] somaVendasMensais = new int[vendedores.length];

		for (int numVendedor = 0; numVendedor < vendedores.length; numVendedor++) {
			for (int auxSemanas = 0; auxSemanas < qtdSemanas; auxSemanas++)
				somaVendasMensais[numVendedor] += vendedores[numVendedor].getVendaSemanal(auxSemanas);
		}
		return somaVendasMensais;
	}
}
