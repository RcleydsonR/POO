package validacao;

import java.util.InputMismatchException;

import dados.Pessoa;
import leitor.Leitora;
import principal.NomeCompleto;
import saida.Saida;

public class Validacao {

	public static boolean validaContinua() {

		// DECLARACAO
		char opcao;

		// INTRUCOES
		Saida.limpaTela(1);
		System.out.println("Deseja continuar cadastrando?\n Digite 'S' para sim e 'N' para n�o");
		opcao = Leitora.leituraChar();

		while ((opcao != 'S') && (opcao != 'N')) {
			Saida.limpaTela(2);
			System.out.println("Opcao invalida! Continuar cadastrando? Digite 'S' para sim e 'N' para nao: ");
			opcao = Leitora.leituraChar();
		}
		Saida.limpaTela(5);
		return ((opcao == 'S') ? true : false);
	}

	public static String validaNome() {

		// DECLARACAO
		String nome;
		NomeCompleto.qntdEspaco = 0;
		// INSTRUCOES
		do {
			Saida.solicitaNome();
			nome = Leitora.leituraLinha();
			for (int i = 0; i < nome.length(); i++) {
				if (nome.charAt(i) == ' ')
					NomeCompleto.qntdEspaco++;
			}
			if (NomeCompleto.qntdEspaco == 0)
				System.out.println("Nome invalido! O nome nao pode ser vazio e deve ser completo.\n");
		} while (NomeCompleto.qntdEspaco == 0);

		return nome;
	}


}
