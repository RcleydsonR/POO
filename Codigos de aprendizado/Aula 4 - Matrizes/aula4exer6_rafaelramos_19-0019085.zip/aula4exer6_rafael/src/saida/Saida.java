package saida;

import dados.Pessoa;
import principal.NomeCompleto;

public class Saida {

	public static void solicitaNome() {
		System.out.println("Informe o seu nome completo:");
	}

	public static void mostraNomeSeparado(Pessoa pessoa) {
		limpaTela(50);
		for ( int aux = 0; aux <= NomeCompleto.qntdEspaco; aux ++)
			System.out.println(pessoa.getNomeSeparado(aux));
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

}
