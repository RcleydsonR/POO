package principal;

import dados.Pessoa;
import leitor.Leitora;
import validacao.Validacao;
import saida.Saida;

public class NomeCompleto {
	
	public static int qntdEspaco;
	public static void main(String[] args) {
		// DECLARACAO
		Pessoa pessoa = new Pessoa();
		// INSTRUCOES
		do {
			pessoa.setNome(Validacao.validaNome());
			pessoa.setNomeSeparado(pessoa.getNome().toUpperCase().split(" "));
			Saida.mostraNomeSeparado(pessoa);
		} while (Validacao.validaContinua());
	}
}
