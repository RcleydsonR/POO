package dados;

public class Pessoa {
	private String nome;
	private String[] nomeSeparado;

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNomeSeparado(String[] nomeSeparado) {
		this.nomeSeparado = nomeSeparado;
	}

	public String getNomeSeparado(int aux) {
		return this.nomeSeparado[aux];
	}

}
