package saida;

import javax.swing.JOptionPane;

import dados.Pais;

public class Visao {
	public static void mostraMensagem(String mensagem) {
		System.out.println(mensagem);
	}

	public static void msgWarningDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.WARNING_MESSAGE);
	}

	public static void msgErrorDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.ERROR_MESSAGE);
	}

	public static void msgInfoDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.INFORMATION_MESSAGE);
	}

	public static void limpaTela(int qtd) {
		for (int i = 0; i < qtd; i++)
			System.out.println();
	}

	public static void mostraCadastros(Pais pais, int valorContaminados) {
		if (pais.getListaCidades().size() == 0)
			msgWarningDialog("Ainda nao foram feitos cadastros de cidades", "Aviso");
		else if (pais.temContaminadas(pais, valorContaminados)) {
			limpaTela(40);
			mostraMensagem("Cidades que possuem um numero maior ou igual a " + valorContaminados
					+ " de pessoas contaminadas:\n\n");
			System.out.format("%-35s%-10s%-15s%-10s%-2s", "              CIDADE", "| ESTADO", "| CONTAMINADOS",
					"| MORTOS", "|");
			System.out.println("\n=======================================================================");
			pais.mostraContaminadas(pais, valorContaminados);
		} else
			msgInfoDialog("Nao ha nenhuma cidade com um numero de contaminados maior ou igual ao pesquisado",
					"Informacao");
	}

}
