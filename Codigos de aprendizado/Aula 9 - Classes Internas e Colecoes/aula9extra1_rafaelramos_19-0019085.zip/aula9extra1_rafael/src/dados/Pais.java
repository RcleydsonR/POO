package dados;

import java.util.ArrayList;


public class Pais implements Pesquisas {
	private ArrayList<Cidade> listaCidades;

	public Pais() {
		this.listaCidades = new ArrayList<Cidade>();
	}

	public ArrayList<Cidade> getListaCidades() {
		return listaCidades;
	}

	public void setCidade(Cidade cidade) {
		this.listaCidades.add(cidade);
	}

	public boolean contains(Cidade novaCidade) {
		for (Cidade cidade : this.getListaCidades()) {
			if (cidade.equals(novaCidade))
				return true;
		}
		return false;
	}

	public void mostraContaminadas(Pais pais, int valorContaminados) {
		for (Cidade cidade : this.getListaCidades()) {
			if (cidade.getContaminadosCovid() >= valorContaminados)
				System.out.println(cidade);
		}

	}

	public boolean temContaminadas(Pais pais, int valorContaminados) {
		for (Cidade cidade : this.getListaCidades()) {
			if (cidade.getContaminadosCovid() >= valorContaminados)
				return true;
		}
		return false;
	}

}