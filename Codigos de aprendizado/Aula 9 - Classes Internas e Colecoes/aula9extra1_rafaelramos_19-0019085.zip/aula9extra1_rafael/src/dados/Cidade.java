package dados;

public class Cidade {
	private StringBuilder nomeCidade;
	private StringBuilder siglaEstado;
	private Integer contaminadosCovid;
	private Integer mortosCovid;

	public Cidade(StringBuilder nomeCidade, String siglaEstado, Integer contaminadosCovid, Integer mortosCovid) {
		setNomeCidade(nomeCidade);
		setSiglaEstado(siglaEstado);
		setContaminadosCovid(contaminadosCovid);
		setMortosCovid(mortosCovid);
	}

	public StringBuilder getNomeCidade() {
		return nomeCidade;
	}

	public void setNomeCidade(StringBuilder nomeCidade) {
		this.nomeCidade = nomeCidade;
	}

	public StringBuilder getSiglaEstado() {
		return siglaEstado;
	}

	public void setSiglaEstado(String siglaEstado) {
		this.siglaEstado = new StringBuilder(siglaEstado);
	}

	public Integer getContaminadosCovid() {
		return contaminadosCovid;
	}

	public void setContaminadosCovid(Integer contaminadosCovid) {
		this.contaminadosCovid = contaminadosCovid;
	}

	public Integer getMortosCovid() {
		return mortosCovid;
	}

	public void setMortosCovid(Integer mortosCovid) {
		this.mortosCovid = mortosCovid;
	}

	public String toString() {
		return String.format("%-35s%-10s%-15s%-10s%-2s", this.getNomeCidade(), "| " + this.getSiglaEstado(),
				"| " + this.getContaminadosCovid(), "| " + this.getMortosCovid(), "|");
	}

	public boolean equals(Object obj) {
		Cidade novaCidade = (Cidade) obj;
		return (this.getNomeCidade().toString().equalsIgnoreCase(novaCidade.getNomeCidade().toString())
				&& this.getSiglaEstado().toString().equalsIgnoreCase(novaCidade.getSiglaEstado().toString()));
	}

}
