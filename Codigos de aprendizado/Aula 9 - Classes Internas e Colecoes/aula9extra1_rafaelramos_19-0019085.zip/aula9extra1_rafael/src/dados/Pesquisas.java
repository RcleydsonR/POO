package dados;

public interface Pesquisas {
	
	void mostraContaminadas(Pais pais, int valor);

}
