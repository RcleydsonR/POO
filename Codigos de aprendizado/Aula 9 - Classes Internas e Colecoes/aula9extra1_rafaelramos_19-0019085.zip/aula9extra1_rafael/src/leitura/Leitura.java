package leitura;

import javax.swing.JOptionPane;


public class Leitura {
	
	// CAIXA DE TEXTO
	public static String lerShowInputDialog(String msg, String label) {
		return JOptionPane.showInputDialog(null, msg, label, JOptionPane.QUESTION_MESSAGE);
	}
	
	public static int lerSaida() {
		return JOptionPane.showConfirmDialog(null, "Tem certeza que deseja encerra o programa ?", "SAIDA", JOptionPane.YES_NO_OPTION, 
				JOptionPane.ERROR_MESSAGE);
	}
	
	public static int lerMenuOpcoes(String[] opcoes) {
		return JOptionPane.showOptionDialog(null, "Selecione uma opcao:", "MENU", 0, JOptionPane.INFORMATION_MESSAGE,
				null, opcoes, opcoes[0]);
	}
}
