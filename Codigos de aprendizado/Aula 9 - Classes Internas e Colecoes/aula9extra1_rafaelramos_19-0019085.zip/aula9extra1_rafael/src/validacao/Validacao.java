package validacao;

import dados.Cidade;
import dados.Pais;
import leitura.Leitura;
import saida.Visao;

public class Validacao {

	public static int validaEscolhaMenu() {
		String[] opcoes = { "Nova Cidade", "Pesquisa Cidade contaminada", };
		return Leitura.lerMenuOpcoes(opcoes);
	}

	public static StringBuilder validaNomeCidade() {
		StringBuilder nomeCidade = new StringBuilder(
				Leitura.lerShowInputDialog("Informe o nome completo da cidade a ser cadastrada:", "Cadastro da cidade")
						.trim());

		if (nomeCidade.length() < 3) {
			Visao.msgWarningDialog("O nome deve ter pelo menos 3 caracteres e nao pode ser vazio! Tente novamente.",
					"Aviso");
			return validaNomeCidade();
		}

		return nomeCidade;
	}

	public static String validaSiglaEstado() {
		String siglaEstado = Leitura.lerShowInputDialog("Informe a sigla do estado o qual essa cidade pertence:",
				"Cadastro da sigla");

		if (siglaEstado.trim().length() != 2 || isNomeComDigitos(siglaEstado)) {
			Visao.msgWarningDialog(
					"A sigla pode possuir apenas 2 caracteres (ex: SP - Sao Paulo) e nao pode conter digitos! Tente novamente.",
					"Aviso");
			return validaSiglaEstado();
		} 
		return siglaEstado.toUpperCase();
	}

	public static int validaContaminadosCovid(String mensagem) {
		return validaInteiro(mensagem);
	}

	public static int validaMortosCovid(String mensagem, int contaminados) {
		int mortos = validaInteiro(mensagem);
		if (mortos > contaminados) {
			Visao.msgWarningDialog("O numero de mortos nao pode ser maior que o de contaminados", "Aviso");
			return validaMortosCovid(mensagem, contaminados);
		}
		return mortos;
	}

	public static int validaValorPesquisa() {
		return validaInteiro("Digite o valor de contaminados minimo para analise de cidades.");
	}

	private static int validaInteiro(String mensagem) {
		int valor = -1;

		try {
			valor = Integer.parseInt(Leitura.lerShowInputDialog(mensagem, "Valida inteiro"));
			if (valor < 0) {
				Visao.msgErrorDialog("O valor deve ser maior ou igual a 0", "Erro");
				valor = validaInteiro(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.msgErrorDialog("Deve haver um inteiro como entrada.", "Erro");
			valor = validaInteiro(mensagem);
		}
		return valor;
	}

	private static boolean isNomeComDigitos(String nome) {
		for (char c : nome.toCharArray()) {
			if (Character.isDigit(c)) {
				return true;
			}
		}
		return false;
	}

	public static Cidade criaCidade(Pais pais) {
		int contaminados;

		Cidade cidade = new Cidade(validaNomeCidade(), validaSiglaEstado(),
				contaminados = validaContaminadosCovid("Informe o numero de contaminados por covid-19 nessa cidade"),
				validaMortosCovid("Informe o numero de mortos por covid-19 nesta cidade", contaminados));
		if(pais.contains(cidade)) {
			Visao.msgErrorDialog("Esta cidade ja havia sido criada. Tente novamente", "Erro");
			return criaCidade(pais);
		}
		
		return cidade;
	}
	
	public static void registraCidade(Pais pais) {
		pais.setCidade(criaCidade(pais));
	}

}
