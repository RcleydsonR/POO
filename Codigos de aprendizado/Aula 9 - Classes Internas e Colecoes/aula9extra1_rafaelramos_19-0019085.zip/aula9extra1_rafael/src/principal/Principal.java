package principal;

import dados.Pais;
import leitura.Leitura;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {
		Pais pais = new Pais();

		while (exibirMenu(pais))
			;

	}

	public static boolean exibirMenu(Pais pais) {

		try {
			switch (Validacao.validaEscolhaMenu()) {

			case 0:
				Validacao.registraCidade(pais);
				return true;

			case 1:
				Visao.mostraCadastros(pais, Validacao.validaValorPesquisa());
				return true;

			default:
				if (Leitura.lerSaida() == 0)
					return false;
				return true;

			}
		} catch (NullPointerException e) {
			return true;
		}
	}
}