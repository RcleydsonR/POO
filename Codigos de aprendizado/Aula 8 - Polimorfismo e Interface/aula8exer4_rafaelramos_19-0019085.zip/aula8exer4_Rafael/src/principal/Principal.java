package principal;

import dados.Imobiliaria;
import saida.Visao;
import validacao.Validacao;

public class Principal {
	public static int escolha = 1;
	public static void main(String[] args) {
		// ATRIBUTOS
		Imobiliaria imobiliaria = new Imobiliaria();

		// METODO
		exibirCadastro(imobiliaria);
		while(escolha == 1)
			exibirMenu(imobiliaria);
		Visao.mostraCadastros(imobiliaria);
		
	}

	public static void exibirCadastro(Imobiliaria imobiliaria) {
		int escolhaCadastro = Validacao.validaEscolhaCadastro();
		
		switch (escolhaCadastro) {
		case 0:
			Validacao.registraEmpregado(imobiliaria);
			break;

		case 1:
			Validacao.registraTerreno(imobiliaria);
			break;
		default:
			escolha = 0;

		}
	}
	
	public static void exibirMenu(Imobiliaria imobiliaria) {
		int escolhaMenu = Validacao.validaEscolhaMenu();
		switch (escolhaMenu) {
		case 0:
			exibirCadastro(imobiliaria);
			break;

		case 1:
			Visao.mostraAnalise(imobiliaria);
			break;
			
		default:
			escolha = 0;

		}
	}
}