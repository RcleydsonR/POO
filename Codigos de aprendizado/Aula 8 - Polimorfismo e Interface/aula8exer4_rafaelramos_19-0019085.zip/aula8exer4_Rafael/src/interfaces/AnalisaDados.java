package interfaces;


public interface AnalisaDados {
	//byte opcao // 1 = Analisar Empregados; 2 = Analisar Terrenos
	public float menorValor(byte op�ao);

	public float maiorValor(byte opcao);
	
	public boolean isValorIgual(int valorAnalisado, byte opcao);
	
	public float somaDados(byte opcao);
	
	public float mediaDados(byte opcao);
}
