package saida;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

import dados.Empregado;
import dados.Imobiliaria;
import dados.Terreno;
import validacao.Validacao;

public class Visao {
	public static void mostraMensagem(String mensagem) {
		System.out.println(mensagem);
	}

	public static void msgWarningDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.WARNING_MESSAGE);
	}

	public static void msgErrorDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.ERROR_MESSAGE);
	}

	public static void msgInfoDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.INFORMATION_MESSAGE);
	}

	public static void limpaTela(int qtd) {
		for (int i = 0; i < qtd; i++)
			System.out.println();
	}

	public static void mostraCadastros(Imobiliaria imobiliaria) {
		if (imobiliaria.getListaEmpregados().size() == 0) {
			mostraMensagem("N�o foi realizado nenhum cadastro de empregado.\n\n");
		} else {
			System.out.format("%-10s%-15s%-30s%-20s%-2s", "EMPREGADO", "|  MATRICULA", "|    NOME COMPLETO", "| SALARIO", "|");
			mostraMensagem("\n=====================================================================================");
			for (Empregado empregado : imobiliaria.getListaEmpregados())
				System.out.println(empregado);
			limpaTela(2);
		}
			if(imobiliaria.getListaTerrenos().size() == 0)
				mostraMensagem("N�o foi realizado nenhum cadastro de terreno.\n\n");
			else {
			System.out.format("%-10s%-45s%-15s%-25s%-2s", "TERRENO", "|  ENDERECO TERRENO", "|  AREA ", "| VALOR TERRENO", "|");
			mostraMensagem("\n===============================================================================================");
			for (Terreno terreno : imobiliaria.getListaTerrenos())
				System.out.println(terreno);
			limpaTela(2);		
		}
	}

	public static void mostraAnalise(Imobiliaria imobiliaria) {
		switch (Validacao.validaEscolhaAnalise()) {
		case 0:// DADOS DOS EMPREGADOS
			switch (Validacao.validaEscolhaAnaliseEmpregados()) {
			case 0:
				exibirMaiorEMenorSalario(imobiliaria);
				break;
			case 1:
				exibirSomaSalario(imobiliaria);
				break;
			case 2:
				exibirMediaSalario(imobiliaria);
			}
			break;
		case 1:
			switch (Validacao.validaEscolhaAnaliseTerrenos()) {
			case 0:
				exibirMaiorEMenorTerreno(imobiliaria);
				break;
			case 1:
				exibirDuplicidadeTerreno(imobiliaria);
				break;
			case 2:
				exibirSomaTerrenos(imobiliaria);
				break;
			case 3:
				exibirMediaTerrenos(imobiliaria);
			}
		}
	}

	public static void exibirMaiorEMenorSalario(Imobiliaria imobiliaria) {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		if (imobiliaria.getListaEmpregados().size() == 0)
			msgWarningDialog("Nao ha cadastros de empregados", "Aviso");
		else {
			msgInfoDialog("Menor salario: R$" + mascara.format(imobiliaria.menorValor((byte) 1))
					+ "\nMaior salario: R$ " + mascara.format(imobiliaria.maiorValor((byte) 1)),
					"Maior e Menor Salario dos Empregados");
		}
	}

	public static void exibirSomaSalario(Imobiliaria imobiliaria) {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		if (imobiliaria.getListaEmpregados().size() == 0)
			msgWarningDialog("Nao ha cadastros de empregados", "Aviso");
		else {
			msgInfoDialog("Soma dos salarios: R$" + mascara.format(imobiliaria.somaDados((byte) 1)),
					"Soma salarial total");
		}
	}

	public static void exibirMediaSalario(Imobiliaria imobiliaria) {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		if (imobiliaria.getListaEmpregados().size() == 0)
			msgWarningDialog("Nao ha cadastro de empregados", "Aviso");
		else {
			msgInfoDialog("Media salarial: R$ " + mascara.format(imobiliaria.mediaDados((byte) 1)), "Media Salarial");
		}
	}

	public static void exibirMaiorEMenorTerreno(Imobiliaria imobiliaria) {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		if (imobiliaria.getListaTerrenos().size() == 0)
			msgWarningDialog("Nao ha cadastro de terrenos", "Aviso");
		else {
			msgInfoDialog(
					"Menor valor de terreno: R$ " + mascara.format(imobiliaria.menorValor((byte) 2))
							+ "\nMaior valor de terreno: R$ " + mascara.format(imobiliaria.maiorValor((byte) 2)),
					"Maior e Menor valor de terreno");
		}
	}

	public static void exibirDuplicidadeTerreno(Imobiliaria imobiliaria) {
		int areaAnalisada = Validacao.validaArea("Informe a area que deseja verificar se ha duplicidade");

		if (imobiliaria.isValorIgual(areaAnalisada, (byte) 2))
			msgInfoDialog("Ha duplicidade de areas de terrenos", "Verifica duplicidade");
		else
			msgInfoDialog("Nao ha duplicidade de areas de terrenos", "Verifica duplicidade");
	}
	
	public static void exibirSomaTerrenos(Imobiliaria imobiliaria) {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		if (imobiliaria.getListaTerrenos().size() == 0)
			msgWarningDialog("Nao ha cadastros de terrenos", "Aviso");
		else {
			msgInfoDialog("Soma das areas: " + mascara.format(imobiliaria.somaDados((byte) 2)) + " m�"
					+ "\nSoma dos valores dos terrenos: R$ " + mascara.format(imobiliaria.somaDados((byte) 3)), "Somatorio Terrenos");
		}
	}

	public static void exibirMediaTerrenos(Imobiliaria imobiliaria) {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		if (imobiliaria.getListaTerrenos().size() == 0)
			msgWarningDialog("Nao ha cadastros de terrenos", "Aviso");
		else {
			msgInfoDialog("Media das areas: " + mascara.format(imobiliaria.mediaDados((byte) 2)) + " m�"
					+ "\nMedia de valor dos terrenos: R$ " + mascara.format(imobiliaria.mediaDados((byte) 3)), "Media Terrenos");
		}
	}

}
