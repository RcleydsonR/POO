package dados;

import java.text.DecimalFormat;

public class Empregado {
	private StringBuilder nome;
	private Integer matricula;
	private Float salario;

	public Empregado(String nome, int matricula, float salario) {
		this.nome = new StringBuilder(nome);
		setMatricula(matricula);
		setSalario(salario);
	}

	public StringBuilder getNome() {
		return nome;
	}

	public Integer getMatricula() {
		return matricula;
	}

	public void setMatricula(Integer matricula) {
		this.matricula = matricula;
	}

	public Float getSalario() {
		return salario;
	}

	public void setSalario(Float salario) {
		this.salario = salario;
	}

	public String toString() {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		return String.format("%-10s%-15s%-30s%-20s%-2s", "", "| " + this.getMatricula(), "| " + this.getNome(),
				"| R$ " + mascara.format(this.getSalario()), "|");
	}
}
