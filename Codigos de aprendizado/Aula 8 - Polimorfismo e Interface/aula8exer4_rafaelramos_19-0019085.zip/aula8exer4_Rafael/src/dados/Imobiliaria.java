package dados;

import java.util.ArrayList;

import interfaces.AnalisaDados;

public class Imobiliaria implements AnalisaDados{
	private ArrayList<Empregado> listaEmpregados;
	private ArrayList<Terreno> listaTerrenos;
	
	public Imobiliaria () {
		this.listaEmpregados = new ArrayList<Empregado>();
		this.listaTerrenos = new ArrayList<Terreno>();
	}

	public ArrayList<Terreno> getListaTerrenos () {
		return listaTerrenos;
	}

	public void setTerreno (Terreno terreno) {
		this.listaTerrenos.add(terreno);
	}

	public ArrayList<Empregado> getListaEmpregados () {
		return listaEmpregados;
	}

	public void setEmpregado (Empregado empregado) {
		this.listaEmpregados.add(empregado);
	}

	public float menorValor(byte opcao) {
		float menorValor = 0f;
		//opcao 1 = "Empregados" opcao 2 = "Terrenos"
		switch (opcao) {
		case 1:
			menorValor = this.getListaEmpregados().get(0).getSalario();
			for(Empregado empregado : this.getListaEmpregados()) {
				if(empregado.getSalario() < menorValor)
					menorValor = empregado.getSalario();
			}
			break;
		case 2:
			menorValor = this.getListaTerrenos().get(0).getValorTerreno();
			for(Terreno terreno : this.getListaTerrenos()) {
				if(terreno.getValorTerreno() < menorValor)
					menorValor = terreno.getValorTerreno();
			}
		}
		return menorValor;
	}

	public float maiorValor(byte opcao) {
		float maiorValor = 0f;
		//opcao 1 = "Empregados" opcao 2 = "Terrenos"
		switch (opcao) {
		case 1:
			maiorValor = this.getListaEmpregados().get(0).getSalario();
			for(Empregado empregado : this.getListaEmpregados()) {
				if(empregado.getSalario() > maiorValor)
					maiorValor = empregado.getSalario();
			}
			break;
		case 2:
			maiorValor = this.getListaTerrenos().get(0).getValorTerreno();
			for(Terreno terreno : this.getListaTerrenos()) {
				if(terreno.getValorTerreno() > maiorValor)
					maiorValor = terreno.getValorTerreno();
			}
		}
		return maiorValor;
	}

	public boolean isValorIgual(int valorAnalisado, byte opcao) {
		switch (opcao) {
		case 1://EMPREGADO
			for(Empregado empregado : this.getListaEmpregados()) {
				if(empregado.getMatricula() == valorAnalisado)
					return true;
			}
			break;
		case 2://AREA TERRENOS
			int contador = 0;
			for(Terreno terreno : this.getListaTerrenos()) {
					if(terreno.getArea() == valorAnalisado) {
						System.out.println(terreno.getEndereco());
						contador++;
					}
			}
			return (contador > 1);
		}
		return false;
	}

	public float somaDados(byte opcao) {
		float somaNumeros = 0f;

		switch (opcao) {
		case 1:// EMPREGADOS
			somaNumeros = 0f;
			for(Empregado empregado : this.getListaEmpregados()) {
					somaNumeros += empregado.getSalario();
			}
			break;
		case 2:// AREA DOS TERRENOS
			somaNumeros= 0f;
			for(Terreno terreno : this.getListaTerrenos()) {
					somaNumeros += terreno.getArea();
			}
			break;
		case 3:// VALOR DOS TERRENOS
			somaNumeros= 0f;
			for(Terreno terreno : this.getListaTerrenos()) {
					somaNumeros += terreno.getValorTerreno();
			}
			break;
		}
		return somaNumeros;
	}

	public float mediaDados(byte opcao) {
		float mediaNumeros = 0f;
		
		switch (opcao) {
		case 1: //Salario Empregados
				mediaNumeros = somaDados(opcao)/this.getListaEmpregados().size();
			break;
		case 2: //Area terreno
				mediaNumeros = somaDados(opcao)/this.getListaTerrenos().size();
			break;
		case 3: // Valor Terreno
				mediaNumeros = somaDados(opcao)/this.getListaTerrenos().size();
		}
		return mediaNumeros;
	}

}
