package dados;

import java.text.DecimalFormat;

public class Terreno {
	private StringBuilder endereco;
	private Integer area;
	private Float valorTerreno;

	public Terreno(String endereco, Integer area, Float valorTerreno) {
		this.endereco = new StringBuilder(endereco);
		setArea(area);
		setValorTerreno(valorTerreno);
	}

	public StringBuilder getEndereco() {
		return endereco;
	}

	public Float getValorTerreno() {
		return valorTerreno;
	}

	public void setValorTerreno(Float valorTerreno) {
		this.valorTerreno = valorTerreno;
	}

	public Integer getArea() {
		return area;
	}

	public void setArea(Integer area) {
		this.area = area;
	}

	public String toString() {
		DecimalFormat mascara = new DecimalFormat("#0.00");
		return String.format("%-10s%-45s%-15s%-25s%-2s", "", "| " + this.getEndereco(), "| " + this.getArea() +" m�",
				"| R$ " + mascara.format(this.getValorTerreno()), "|");
	}
	
}
