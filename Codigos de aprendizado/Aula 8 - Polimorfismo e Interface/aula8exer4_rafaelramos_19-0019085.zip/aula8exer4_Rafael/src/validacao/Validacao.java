package validacao;

import dados.Empregado;
import dados.Imobiliaria;
import dados.Terreno;
import leitura.Leitura;
import saida.Visao;

public class Validacao {

	public static int validaEscolhaCadastro() {
		String[] opcoes = { "Cadastrar empregado", "Cadastrar terreno" };
		return Leitura.lerMenuOpcoes(opcoes);
	}
	
	public static int validaEscolhaMenu() {
		String[] opcoes = { "Realizar um novo cadastro", "Analise de dados", "Encerrar o programa" };
		return Leitura.lerMenuOpcoes(opcoes);
	}
	
	public static int validaEscolhaAnalise() {
		String[] opcoes = { "Analisar dados dos Empregados", "Analise dados dos Terrenos"};
		return Leitura.lerMenuOpcoes(opcoes);
	}
	
	public static int validaEscolhaAnaliseEmpregados() {
		String[] opcoes = { "Analisar maior e menor valor dos salarios", "Analise da soma dos salarios", "Analise da media salarial"};
		return Leitura.lerMenuOpcoes(opcoes);
	}
	
	public static int validaEscolhaAnaliseTerrenos() {
		String[] opcoes = { "Analisar maior e menor valor dos terrenos", "Verificar se ha duplicidade de area", "Analise da soma das areas e valores dos terrenos", "Analise da media das areas e valores dos terrenos"};
		return Leitura.lerMenuOpcoes(opcoes);
	}
	
	public static String validaNome() {
		String nome = Leitura.lerShowInputDialog("Informe o nome completo do empregado:", "Cadastro do nome");

		if (nome == null || nome.split(" ")[0].equals(nome.trim()) || isNomeComDigitos(nome)) {
			Visao.msgWarningDialog("O nome deve ser completo e nao pode ter digitos! Tente novamente.", "Aviso");
			return validaNome();
		}

		return nome;
	}

	public static String validaEndereco() {
		String endereco = Leitura.lerShowInputDialog("Informe o endereco completo do terreno:", "Cadastro do endereco");

		if (endereco == null || endereco.split(" ")[0].equals(endereco.trim())) {
			Visao.msgWarningDialog("O endereco deve ser completo! Tente novamente.", "Aviso");
			return validaEndereco();
		}

		return endereco;
	}

	public static int validaMatricula(Imobiliaria imobiliaria, String mensagem) {
		int matricula = validaInteiro(mensagem);
		if (imobiliaria.isValorIgual(matricula, (byte) 1)) {
			Visao.msgWarningDialog("Matricula ja cadastrada, tente novamente", "Aviso");
			return validaMatricula(imobiliaria, mensagem);
		}
		return matricula;
	}

	public static float validaSalario(String mensagem) {
		float salario = validaFloat(mensagem);
		return salario;
	}

	public static int validaArea(String mensagem) {
		int area = validaInteiro(mensagem);
		return area;
	}

	public static float validaPrecoTerreno(String mensagem) {
		float valorTerreno = validaFloat(mensagem);
		return valorTerreno;
	}

	private static int validaInteiro(String mensagem) {
		int valor = -1;

		try {
			valor = Integer.parseInt(Leitura.lerShowInputDialog(mensagem, "Valida inteiro"));
			if (valor <= 0) {
				Visao.msgErrorDialog("O valor deve ser positivo", "Erro");
				valor = validaInteiro(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.msgErrorDialog("Deve haver um inteiro como entrada.", "Erro");
			valor = validaInteiro(mensagem);
		}
		return valor;
	}

	private static float validaFloat(String mensagem) {
		float valor = -1f;

		try {
			valor = Float.parseFloat(Leitura.lerShowInputDialog(mensagem, "Valida Numero"));
			if (valor <= 0) {
				Visao.msgErrorDialog("O valor deve ser positivo", "Erro");
				valor = validaFloat(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.msgErrorDialog("Deve haver uma entrada numerica.", "Erro");
			valor = validaFloat(mensagem);
		} catch (NullPointerException e_2) {
			Visao.msgErrorDialog("\nInsira algum dado!", "Erro");
			valor= validaFloat(mensagem);
		}
		
		return valor;
	}

	private static boolean isNomeComDigitos(String nome) {
		for (char c : nome.toCharArray()) {
			if (Character.isDigit(c)) {
				return true;
			}
		}
		return false;
	}


	public static void registraEmpregado(Imobiliaria imobiliaria) {
		Empregado empregado = new Empregado(validaNome(),
				validaMatricula(imobiliaria, "Informe a matricula funcional do empregado"),
				validaSalario("Informe o salario do empregado (em reais)"));
		imobiliaria.setEmpregado(empregado);
	}

	public static void registraTerreno(Imobiliaria imobiliaria) {
		Terreno terreno = new Terreno(validaEndereco(), validaArea("Informe o tamanho da area deste terreno (em m�)"),
				validaPrecoTerreno("Informe o preco atual deste terreno (em reais)."));
		imobiliaria.setTerreno(terreno);
	}

}
