package Principal;

public class CadastroPessoas {

	final static int LIMITE = 50;

	public static void main(String[] args) {
		// Declaracoes
		int qntdPessoas = 0;
		Grupo grupo = new Grupo();
		// Instru��es
		do {
			grupo.addPessoa(qntdPessoas);
			qntdPessoas++;
		} while (Validacao.validaContinua(qntdPessoas));
		Saida.mostraTabela(grupo, qntdPessoas);
	}
}
