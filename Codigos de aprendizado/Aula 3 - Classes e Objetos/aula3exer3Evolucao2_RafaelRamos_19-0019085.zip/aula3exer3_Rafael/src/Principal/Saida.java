package Principal;

import java.text.DecimalFormat;

public class Saida {

	public static void mostraTabela(Grupo grupo, int qntdPessoas) {
		Servicos.limpaTela(50);
		DecimalFormat centesimo = new DecimalFormat("0.00");
		System.out.println("IDADE\tALTURA\tNOME");
		for (int aux = 0; aux < qntdPessoas; aux++) {
			System.out.println(grupo.getPessoa()[aux].getIdade() + "\t"
					+ centesimo.format(grupo.getPessoa()[aux].getAltura()) + "\t" + grupo.getPessoa()[aux].getNome());
		}

	}
}
