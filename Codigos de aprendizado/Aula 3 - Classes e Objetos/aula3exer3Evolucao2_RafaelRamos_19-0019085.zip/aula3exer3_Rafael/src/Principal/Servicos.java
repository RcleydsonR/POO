package Principal;

import java.text.*;

public class Servicos {

	// Salta quantidade de linhas desejadas
	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

	public static void solicitaIdade() {
		System.out.println("Digite a Idade da pessoa a ser cadastrada ");
	}

	public static void solicitaNome() {
		System.out.println("Digite o nome da pessoa a ser cadastrada ");
	}

	public static void solicitaAltura() {
		System.out.println("Digite a altura da pessoa a ser cadastrada(em metros):");
	}
}
