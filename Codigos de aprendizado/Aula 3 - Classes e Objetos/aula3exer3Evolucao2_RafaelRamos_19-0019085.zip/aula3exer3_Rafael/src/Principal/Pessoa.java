package Principal;

public class Pessoa {
	// Declaracoes
	private float altura;
	private int idade;
	private String nome;

	// Instrucoes
	// Metodo construtor
	Pessoa(String nome, int idade, float altura) {
		setNome(nome);
		setIdade(idade);
		setAltura(altura);
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return this.nome;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public int getIdade() {
		return this.idade;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	public float getAltura() {
		return this.altura;
	}
}
