package principal;

import dados.Grupo;
import saida.Saida;
import validacao.Validacao;

public class CadastroPessoas {

	public final static int LIMITE = 50;
	public static final float ALTURA_MIN = 0.4F;
	public static final float ALTURA_MAX = 2.6F;
	public final static int IDADE_MIN = 1;
	public final static int IDADE_MAX = 149;

	public static void main(String[] args) {
		// Declaracoes
		int qntdPessoas = 0;
		Grupo grupo = new Grupo();
		// Instru��es
		do {
			grupo.addPessoa(qntdPessoas);
			qntdPessoas++;
		} while (Validacao.validaContinua(qntdPessoas));
		Saida.mostraTabela(grupo, qntdPessoas);
	}
}
