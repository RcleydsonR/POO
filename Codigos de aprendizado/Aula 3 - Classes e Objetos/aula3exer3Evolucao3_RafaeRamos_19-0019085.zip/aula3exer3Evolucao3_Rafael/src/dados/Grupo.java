package dados;

import principal.CadastroPessoas;
import validacao.Validacao;

public class Grupo {

	private Pessoa variaspessoas[] = new Pessoa[CadastroPessoas.LIMITE];

	public void addPessoa(int aux) {
		this.variaspessoas[aux] = new Pessoa(Validacao.validaNome(), Validacao.validaIdade(), Validacao.validaAltura());
	}

	public Pessoa[] getPessoa() {
		return this.variaspessoas;
	}
}
