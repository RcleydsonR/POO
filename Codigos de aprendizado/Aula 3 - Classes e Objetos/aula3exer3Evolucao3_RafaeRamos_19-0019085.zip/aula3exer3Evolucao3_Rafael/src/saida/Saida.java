package saida;

import java.text.DecimalFormat;

import dados.Grupo;

public class Saida {

	public static void mostraTabela(Grupo grupo, int qntdPessoas) {
		Servicos.limpaTela(50);
		DecimalFormat centesimo = new DecimalFormat("0.00");
		System.out.println("     IDADE \t | \t ALTURA \t | \t NOME");
		for (int i = 0; i < 64; i++)
			System.out.print("-");
		System.out.println();
		for (int aux = 0; aux < qntdPessoas; aux++) {
			System.out.print("  \t" + grupo.getPessoa()[aux].getIdade() + "  \t |");
			System.out.print("  \t   " + centesimo.format(grupo.getPessoa()[aux].getAltura()) + "  \t |");
			System.out.println("   " + grupo.getPessoa()[aux].getNome());
		}
	}
}
