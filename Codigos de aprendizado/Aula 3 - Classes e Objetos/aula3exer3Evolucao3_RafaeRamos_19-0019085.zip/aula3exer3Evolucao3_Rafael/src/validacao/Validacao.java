package validacao;

import java.util.InputMismatchException;

import leitura.Leitura;
import principal.CadastroPessoas;
import saida.Servicos;

public class Validacao {

	// Valida opcao de continuar cadastro
	public static boolean validaContinua(int aux) {
		// Declaracoes
		char opcao;
		// Instrucoes
		Servicos.limpaTela(2);
		if (aux < CadastroPessoas.LIMITE) {
			System.out.println("Deseja continuar cadastrando?\n Digite 'S' para sim e 'N' para n�o");
			opcao = Leitura.leituraChar();

			while ((opcao != 'S') && (opcao != 'N')) {
				Servicos.limpaTela(3);
				System.out.print("Op��o inv�lida! Continuar cadastrando?\nDigite 'S' para sim e 'N' para n�o: ");
				opcao = Leitura.leituraChar();
			}
			Servicos.limpaTela(3);
			return ((opcao == 'S') ? true : false);
		} else
			return false;
	}

	// Valida Altura
	public static float validaAltura() {
		// Declaracoes
		boolean erro = false;
		float altura = 0;

		// Instrucoes
		do {
			Servicos.solicitaAltura();
			try {
				altura = Leitura.leituraFloat();
				if (altura < CadastroPessoas.ALTURA_MIN || altura > CadastroPessoas.ALTURA_MAX) {
					Servicos.limpaTela(1);
					System.out.println("Valor invalido! Digite uma altura entre " + CadastroPessoas.ALTURA_MIN + " e "
							+ CadastroPessoas.ALTURA_MAX + " metros.");
					erro = true;
				} else
					erro = false;
			} catch (InputMismatchException excecao) {
				System.out.println("Ocorreu um  erro.");
				erro = true;
			}
		} while (erro);
		return altura;
	}

	// Vallida Idade
	public static int validaIdade() {
		// Declaracoes
		boolean erro = false;
		int idade = 0;

		// Instrucoes
		do {
			Servicos.solicitaIdade();
			try {
				idade = Leitura.leituraInt();
				if (idade < CadastroPessoas.IDADE_MIN || idade > CadastroPessoas.IDADE_MAX) {
					Servicos.limpaTela(1);
					System.out.println("Valor invalido! Digite uma idade entre " + CadastroPessoas.IDADE_MIN + " e "
							+ CadastroPessoas.IDADE_MAX + "  anos.");
					erro = true;
				} else
					erro = false;
			} catch (InputMismatchException excecao) {
				System.out.println("Ocorreu um  erro. O numero digitado deve ser inteiro");
				erro = true;
			}
		} while (erro);
		return idade;
	}

	// Valida Nome
	public static String validaNome() {
		// Declaracao
		String nome;

		// Instrucoes
		Servicos.solicitaNome();
		nome = Leitura.leituraLinha();

		while (nome.length() < 3 || nome.isEmpty()) {
			Servicos.limpaTela(1);
			System.out.print(
					"Nome invalido! O nome deve ter pelo menos 3 caracteres e nao pode ser vazio.\nDigite o nome novamente: ");
			nome = Leitura.leituraLinha();
		}
		return nome;
	}
}
