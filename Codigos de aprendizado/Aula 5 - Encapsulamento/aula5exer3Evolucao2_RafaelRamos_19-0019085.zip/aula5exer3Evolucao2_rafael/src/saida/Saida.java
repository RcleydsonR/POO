package saida;

import java.text.DecimalFormat;

import dados.Populacao;
import servicos.Servicos;

public class Saida {
	// Apresenta o resultado final
	public static void imprimeResultado(Populacao habitantes) {
		DecimalFormat mascara = new DecimalFormat("0.00");
		DecimalFormat inteiro = new DecimalFormat("0");
		float resultados[] = Servicos.resultados(habitantes);
		Saida.limpaTela(50);
		System.out.println("Foram feitos " + habitantes.getPopulacao().size() + " cadastro(s)");
		System.out.println("Relatorio de analise do(s) dado(s) cadastrado(s)\n");
		System.out.println("Menor idade entre os entrevistados = " + inteiro.format(resultados[0]));
		System.out.println("Maior salario entre os entrevistados = " + mascara.format(resultados[1]));
		System.out.println("Media do numero de filhos entre todos cadastros = " + mascara.format(resultados[2]));
		System.out.println("Media do salario das pessoas registradas = " + mascara.format(resultados[3]));
		System.out
				.println("Porcentagem dos homens com salario superior a 300 = " + mascara.format(resultados[4]) + "%");
		System.out.println(
				"Quantidade de pessoas que tem o salario maior que a media de salario de todas as pessoas registradas = "
						+ inteiro.format(resultados[5]));
	}

	// Salta quantidade de linhas desejadas
	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}
}
