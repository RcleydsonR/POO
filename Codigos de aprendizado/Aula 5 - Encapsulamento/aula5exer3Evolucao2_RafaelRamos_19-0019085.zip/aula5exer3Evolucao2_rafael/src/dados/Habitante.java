package dados;

public class Habitante {
	// Declaracoes
	private Float salario;
	private Integer idade;
	private Integer numeroFilhos;
	private Character sexo;

	// Metodo construtor
	public Habitante(Float salario, Integer idade, Character sexo, Integer numeroFilhos) {
		setSalario(salario);
		setIdade(idade);
		setSexo(sexo);
		setNumeroFilhos(numeroFilhos);
	}

	// Getters e Setters
	public Float getSalario() {
		return salario;
	}

	public void setSalario(Float salario) {
		this.salario = salario;
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	public Integer getNumeroFilhos() {
		return numeroFilhos;
	}

	public void setNumeroFilhos(Integer numeroFilhos) {
		this.numeroFilhos = numeroFilhos;
	}

	public Character getSexo() {
		return sexo;
	}

	public void setSexo(Character sexo) {
		this.sexo = sexo;
	}

}
