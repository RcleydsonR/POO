package dados;

import java.util.Vector;

public class Populacao {
	// Declaracoes
	private Vector<Habitante> habitantes;

	// Metodo Construtor
	public Populacao() {
		habitantes = new Vector<Habitante>();
	}

	public Vector<Habitante> getPopulacao() {
		return this.habitantes;
	}

	public Habitante getHabitante(int numHab) {
		return habitantes.get(numHab);
	}

	public void setPopulacao(Habitante habitante) {
		this.habitantes.add(habitante);
	}

}