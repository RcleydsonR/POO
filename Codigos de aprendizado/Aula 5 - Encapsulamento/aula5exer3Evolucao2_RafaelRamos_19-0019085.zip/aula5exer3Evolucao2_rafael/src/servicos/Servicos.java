package servicos;


import dados.*;

public class Servicos {

	public static float[] resultados(Populacao habitantes) {
		//DECLARACOES
		float resultados[] = new float[6];
		float menorIdade = 150;
		float maiorSalario = 0;
		int numHomens = 0;
		
		/*
		 * resultados[0] = MENOR IDADE ENTRE OS ENTREVISTADOS
		 * resultados[1] = MAIOR SALARIO REGISTRADO
		 * resultados[2] = MEDIA DO NUMFILHOS ENTRE TODOS OS CADASTROS
		 * resultados[3] = MEDIA DO SALARIO DAS PESSOAS REGISTRADAS
		 * resultados[4] = MEDIA DOS HOMENS COM SALARIO SUPERIOR A 300
		 * resultados[5] = QUANTIDADE DAS PESSOAS QUE TEM SALARIO MAIOR QUE A MEDIA DAS PESSOAS REGISTRADAS
		 */

		//INSTRUCOES
		for (int aux = 0; aux < habitantes.getPopulacao().size(); aux++) {
			if (habitantes.getHabitante(aux).getIdade() < menorIdade)
				menorIdade = habitantes.getHabitante(aux).getIdade();
			if (habitantes.getHabitante(aux).getSalario() > maiorSalario)
				maiorSalario = habitantes.getHabitante(aux).getSalario();
			if (habitantes.getHabitante(aux).getSexo() == 'M') {
				numHomens++;
				if (habitantes.getHabitante(aux).getSalario() > 300)
					resultados[4] += 1;
			}
			resultados[2] += habitantes.getHabitante(aux).getNumeroFilhos();
			resultados[3] += habitantes.getHabitante(aux).getSalario();
		}
		resultados[0] = menorIdade;
		resultados[1] = maiorSalario;
		resultados[2] /= habitantes.getPopulacao().size();
		resultados[3] /= habitantes.getPopulacao().size();
		if (numHomens > 0)
			resultados[4] = (resultados[4] / numHomens) * 100;
		resultados[5] = salarioMaiorQueMedia(habitantes, resultados[3]);

		return resultados;
	}

	public static float salarioMaiorQueMedia(Populacao habitantes, Float media) {
		float qntdPessoas = 0;
		for (int aux = 0; aux < habitantes.getPopulacao().size(); aux++) {
			if (habitantes.getHabitante(aux).getSalario() > media)
				qntdPessoas++;
		}
		return qntdPessoas;
	}
}
