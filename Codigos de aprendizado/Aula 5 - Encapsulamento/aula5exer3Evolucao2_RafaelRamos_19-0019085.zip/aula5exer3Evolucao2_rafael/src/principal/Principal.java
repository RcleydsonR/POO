package principal;

import dados.*;
import validacao.Validacao;
import saida.Saida;
import servicos.Servicos;

public class Principal {
	public static void main(String[] args) {
		Populacao habitantes = new Populacao();

		do {
			habitantes.setPopulacao(new Habitante(Validacao.validaSalario(), Validacao.validaIdade(),
					Validacao.validaSexo(), Validacao.validaNumeroFilhos()));
		} while (Validacao.isContinuaCadastro(habitantes.getPopulacao().size()));

		Saida.imprimeResultado(habitantes);
	}
}
