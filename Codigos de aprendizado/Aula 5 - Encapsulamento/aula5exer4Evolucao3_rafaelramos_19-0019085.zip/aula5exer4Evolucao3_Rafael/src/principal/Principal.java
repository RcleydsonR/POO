package principal;

import dados.Pessoa;
import saida.Visao;
import validacao.Validacao;

public class Principal {
	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa();

		do {
			pessoa.getNomes().removeAllElements();
			while (Validacao.validaCadastroNome()) {
				pessoa.setNomes(Validacao.validaNome());
				Visao.limpaTela(2);
			}
			Visao.limpaTela(50);
			Visao.mostraRelatorio(pessoa);
			Visao.limpaTela(50);
		} while (Validacao.validaNovoGrupo());
		Visao.mostraMensagem("A ultima lista teve " + pessoa.getNomes().size() + " nomes cadastrados");
	}
}
