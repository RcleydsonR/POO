package dados;

import java.util.Vector;

public class Pessoa {
	private Vector<String> nomes;
	
	public Pessoa() {
		this.nomes = new Vector<String>();
	}
	
	public Vector<String> getNomes() {
		return nomes;
	}
	
	public void setNomes(String nome) {
		this.nomes.add(nome);
	}
}
