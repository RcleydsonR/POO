package servicos;

import java.util.ArrayList;

import dados.Aluno;
import dados.Turma;

public class Servicos {
	public static float validaMediaGeral(Turma turma) {
		float soma = 0f;
		ArrayList<Aluno> alunosCadastrados = turma.getAlunos();

		for (int i = 0; i < alunosCadastrados.size(); i++)
			soma += alunosCadastrados.get(i).getMediaAritmetica();

		return soma / alunosCadastrados.size();
	}

	public static boolean isMatriculaIgual(Turma turma, int matricula) {
		for (int aux = 0; aux < turma.getAlunos().size(); aux++) {
			if (turma.getAlunos().get(aux).getMatricula() == matricula) {
				System.out
						.println("\nMatricula ja existente !! Impossivel cadastrar outro aluno com a mesma matricula.");
				return true;
			}
		}
		return false;
	}
}
