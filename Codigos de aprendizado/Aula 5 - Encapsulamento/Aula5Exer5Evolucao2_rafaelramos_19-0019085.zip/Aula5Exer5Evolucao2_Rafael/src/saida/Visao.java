package saida;

public class Visao {
	public static void solicitaMatricula() {
		System.out.println("Digite a matr�cula do aluno:");
	}

	public static void solicitaNome() {
		System.out.println("Digite o nome completo do aluno:");
	}

	public static void solicitaNota() {
		System.out.println("Digite a nota do aluno:");
	}
}
