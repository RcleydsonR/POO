package validacao;

import java.util.ArrayList;
import java.util.InputMismatchException;
import dados.Aluno;
import dados.Turma;
import leitura.Leitura;
import saida.Saida;
import saida.Visao;
import servicos.Servicos;

public class Validacao {
	public static String validaNome() {
		String nome;

		System.out.println("-------------------------------CADASTRO-------------------------------");
		do {
			Visao.solicitaNome();
			nome = Leitura.leString();

			if (nome.isEmpty()) {
				System.out.println("\nNome invalido !! Nao eh aceito deixar esse campo em branco");
			}
		} while (nome.isEmpty());
		return nome;
	}

	public static int validaMatricula(Turma turma) {
		int matricula = 0;
		boolean erro;
		final int MAX = 1000;

		do {
			try {
				erro = false;
				Visao.solicitaMatricula();
				matricula = Leitura.leInteiro();

				if (matricula < MAX) {
					System.out.println("\nNumero de matricula invalido !! Digite novamente.");
					erro = true;
					// PRINCIPAL
				} else {
					erro = Servicos.isMatriculaIgual(turma, matricula);
				}
			} catch (InputMismatchException e) {
				System.out.println("\nFormato de matricula invalido !! Digite somente os numeros da matricula");
				erro = true;
			}
		} while (erro);

		return matricula;
	}

	public static float validaMedia() {
		float media = -1f;
		boolean erro;

		do {
			try {
				erro = false;
				Visao.solicitaNota();
				media = Leitura.leFloat();

				if (media < 0 || media > 10) {
					System.out.println("\nMedia invalida !! O valor deve estar entre 0 e 10 !!");
					erro = true;
				}
			} catch (InputMismatchException e) {
				System.out.println(
						"Formato invalido de media !! Se atente ao numero inserido. Caso escreva numero decimal utilize ',' e nao '.' !!\n");
				erro = true;
			}
		} while (erro);
		Saida.limpaConsole(1);

		return media;

	}

	public static boolean isContinuaCadastro() {
		char continua;

		do {
			System.out.print("Deseja cadastrar mais um aluno ? Digite 'Sim' ou 'Nao' para escolher: ");
			continua = Leitura.leCaracter();

			if (continua != 'S' && continua != 'N') {
				System.out.println("Opcao invalida !!\n");
			}
		} while (continua != 'S' && continua != 'N');

		Saida.limpaConsole(20);
		return (continua == 'S' ? true : false);
	}

}
