package dados;

import java.text.DecimalFormat;

public class Funcionario extends Pessoa{

	public Funcionario(String nome, String dataNascimento, String cpf) {
		super(nome, dataNascimento, cpf);
	}
	
	public final float getPiso() {
		return 232.0f;
	}

	public float calculaSalario() {
		return getPiso() * 1.1F;
	}
	
	public byte getIdentificador() {
		return 0;
	}
	
	public String toString() {
		DecimalFormat mascara = new DecimalFormat("0.00");
		return String.format("%-22"
				+ "s%-30s%-15s%-15s%-15s%-5s", "Funcionario Regular", "| " + this.getNome(), "| " + this.getCpf(),
				"| " + this.getDataNascimento(), "| R$ " + mascara.format(this.calculaSalario()), "|");
	}

}
