package principal;

import dados.Galeria;
import dados.Pintor;
import dados.Quadro;
import leitura.Leitura;
import saida.Visao;
import validacao.Validacao;

public class Principal {
	public static void main(String[] args) {
		// Atributos
		Galeria galeria = new Galeria();
		int escolha;
		int codigoPintor = 0;

		// Metodos
		do {
			Visao.limpaTela(2);
			escolha = Validacao.validaEscolha();
			switch (escolha) {
			case 1:
				galeria.setPintor(new Pintor(Validacao.validaNome(),
						Validacao.validaCodigoPessoal(galeria, "Determine o codigo do Pintor:"),
						Validacao.validaAno("Determine o ano de nascimento do pintor:")));
				break;
			case 2:
				if (galeria.getListaPintores().isEmpty()) {
					Visao.msgWarningDialog("� necessario registra ao menos 1 pintor para acessar a opcao.", "Aviso");
				} else {
					galeria.setQuadro(new Quadro(Validacao.validaCodigoQuadro(galeria, "Determine o codigo do Quadro:"),
							codigoPintor = Validacao.validaCodigoPintor(galeria,
									"Determine o codigo do Pintor responsavel pelo quadro:"),
							Validacao.validaPreco("Determine o preco do quadro: [0 caso tenha sido doado]"),
							Validacao.validaAnoQuadro("Determine o ano da compra do quadro:", galeria, codigoPintor
									)));
				}
				break;
			case 3:
				if (galeria.getListaQuadros().isEmpty()) {
					Visao.msgWarningDialog("Eh necessario registrar ao menos 1 quadro para acessar a opcao.", "Aviso");
				} else {
					Visao.mostraQuadrosNome(galeria, Leitura.lerShowInputDialog("Digite o nome a ser procurado:", "Nome do pintor desejado"));
				}
				break;
			case 4:
				if (galeria.getListaQuadros().isEmpty()) {
					Visao.msgWarningDialog("Eh necessario registrar ao menos 1 quadro para acessar a opcao.", "Aviso");
				} else {
					Visao.mostraQuadros(galeria);
				}
			}
		} while (escolha != 5);
	}
}