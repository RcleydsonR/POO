package saida;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

import dados.Galeria;
import dados.Pintor;
import dados.Quadro;

public class Visao {
	public static void mostraMensagem(String mensagem) {
		System.out.println(mensagem);
	}
	
	public static void msgWarningDialog(String label, String fieldset) {
		JOptionPane.showMessageDialog(null, label, fieldset, JOptionPane.WARNING_MESSAGE);
	}
	
	public static void msgErrorDialog(String label, String fieldset) {
		JOptionPane.showMessageDialog(null, label, fieldset, JOptionPane.ERROR_MESSAGE);
	}


	public static void mostraQuadros(Galeria galeria) {
		int indice = 1;

		System.out.format("%-8s%-30s%-30s%-20s%-20s\n", "INDICE", "IDENTIFICACAO QUADRO", "IDENTIFICACAO PINTOR",
				"PRECO", "ANO AQUISICAO");
		for (Quadro quadro : galeria.getListaQuadros()) {
			System.out.format("%-8s%-30s%-30s%-20s%-20s\n", new DecimalFormat("00").format(indice++),
					quadro.getCodigoIdentificacao(), quadro.getCodigoIdentificacaoPintor(),
					new DecimalFormat("0.00").format(quadro.getPreco()), quadro.getAnoAquisicao());
		}
	}

	public static void mostraQuadrosNome(Galeria galeria, String nome) {
		int indice = 1;
		float total = 0f;
		int codigoProcurado = 0;

		limpaTela(50);
		mostraMensagem("Quadro(s) encontrado(s) com [" + nome + "].");
		for (Pintor pintor : galeria.getListaPintores()) {
			if (pintor.getNome().toUpperCase().contains(nome.toUpperCase())) {
				codigoProcurado = pintor.getCodigoPessoal();
				System.out.format("%-8s%-30s%-30s%-20s%-20s\n", "INDICE", "IDENTIFICACAO QUADRO",
						"IDENTIFICACAO PINTOR", "PRECO", "ANO AQUISICAO");
				for (Quadro quadro : galeria.getListaQuadros()) {
					if (quadro.getCodigoIdentificacaoPintor().equals(codigoProcurado)) {
						total += quadro.getPreco();
						System.out.format("%-8s%-30s%-30s%-20s%-20s\n", new DecimalFormat("00").format(indice++),
								quadro.getCodigoIdentificacao(), quadro.getCodigoIdentificacaoPintor(),
								new DecimalFormat("0.00").format(quadro.getPreco()), quadro.getAnoAquisicao());
					}
				}
				limpaTela(2);
				mostraMensagem("Soma total dos valores dos quadros: " + new DecimalFormat("0.00").format(total));
				limpaTela(1);
				total = 0f;
			}
			
		}

		if (codigoProcurado == 0) {
			mostraMensagem("Nenhum quadro encontrado para o pintor [" + nome + "].");
			return;
		}
	}

	public static void limpaTela(int qtd) {
		for (int i = 0; i < qtd; i++)
			System.out.println();
	}
}
