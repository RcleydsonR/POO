package validacao;

import dados.Galeria;
import dados.Pintor;
import dados.Quadro;
import leitura.Leitura;
import saida.Visao;

public class Validacao {
	public static int validaEscolha() {
		String opc;
		String[] select = { "Cadastrar Pintor", "Cadastrar Quadro", "Listar os quadros de acordo com nome do pintor", "Listar todos os quadros", "Encerrar o Programa" };

		try {
			opc = Leitura.lerSelectDialog("Selecione uma opcao", "Selecao de escolha", select, "Cadastro");
		} catch (NullPointerException e) {
			Visao.msgErrorDialog("Selecione uma das opcoes", "Erro");
			return validaEscolha();
		}

		return (getPosicaoSelect(select, opc) == -1) ? validaEscolha() : getPosicaoSelect(select, opc);
	}

	public static String validaNome() {
		String nome = Leitura.lerShowInputDialog("Informe o nome completo do Pintor:", "Cadastro do nome");

		if (nome == null || nome.split(" ")[0].equals(nome.trim()) || isNomeComDigitos(nome)) {
			Visao.msgWarningDialog("O nome deve ser completo e nao pode ter digitos! Tente novamente.", "Aviso");
			return validaNome();
		}

		return nome;
	}



	public static int validaAno(String mensagem) {
		final int ANOMINIMO = 1000, ATUAL = 2020;
		int ano = validaInteiro(mensagem);
		if (ano < ANOMINIMO || ano > ATUAL) {
			Visao.msgWarningDialog("O valor deve estar entre " + ANOMINIMO + " e " + ATUAL + ".", "Aviso");
			ano = validaAno(mensagem);
		}
		return ano;
	}

	public static int validaAnoQuadro(String mensagem, Galeria galeria, int codigoPintor) {
		final int ATUAL = 2020;
		int anoMinimo = 0;
		for (Pintor pintor : galeria.getListaPintores()) {
			if (pintor.getCodigoPessoal() == codigoPintor)
				anoMinimo = pintor.getAnoNascimento();
		}
		int ano = validaInteiro(mensagem);
		if (ano < anoMinimo || ano > ATUAL) {
			Visao.msgWarningDialog("O ano do quadro deve estar entre " + anoMinimo + " e " + ATUAL + ".", "Aviso");
			ano = validaAnoQuadro(mensagem, galeria, codigoPintor);
		}
		return ano;
	}

	public static int validaCodigoPessoal(Galeria galeria, String mensagem) {
		int codigoPessoal = validaInteiro(mensagem);
		if (codigoPessoal < 1 || isCodigoPessoalRepetido(galeria, codigoPessoal)) {
			Visao.msgWarningDialog("O valor do codigo deve ser ao menos 1 e ser unico.", "Aviso");
			codigoPessoal = validaCodigoPessoal(galeria, mensagem);
		}
		return codigoPessoal;
	}

	public static int validaCodigoPintor(Galeria galeria, String mensagem) {
		int codigoPessoal = validaInteiro(mensagem);
		if (codigoPessoal < 1 || !isCodigoPessoalRepetido(galeria, codigoPessoal)) {
			Visao.msgWarningDialog("O valor do codigo deve ser ao menos 1 e pertencer a um pintor.", "Aviso");
			codigoPessoal = validaCodigoPintor(galeria, mensagem);
		}
		return codigoPessoal;
	}

	public static int validaCodigoQuadro(Galeria galeria, String mensagem) {
		int codigoQuadro = validaInteiro(mensagem);
		if (codigoQuadro < 1 || isCodigoQuadroRepetido(galeria, codigoQuadro)) {
			Visao.msgWarningDialog("O valor do codigo deve ser ao menos 1 e ser unico.", "Aviso");
			codigoQuadro = validaCodigoQuadro(galeria, mensagem);
		}
		return codigoQuadro;
	}

	private static boolean isCodigoQuadroRepetido(Galeria galeria, int codigoQuadro) {
		for (Quadro quadro : galeria.getListaQuadros()) {
			if (quadro.getCodigoIdentificacao().equals(codigoQuadro)) {
				return true;
			}
		}
		return false;
	}

	private static boolean isCodigoPessoalRepetido(Galeria galeria, int codigoPessoal) {
		for (Pintor pintor : galeria.getListaPintores()) {
			if (pintor.getCodigoPessoal().equals(codigoPessoal)) {
				return true;
			}
		}
		return false;
	}

	private static int validaInteiro(String mensagem) {
		int valor = -1;

		try {
			valor = Integer.parseInt(Leitura.lerShowInputDialog(mensagem, "Valida inteiro"));
			if (valor < 0) {
				Visao.msgErrorDialog("O valor deve ser positivo", "Erro");
				valor = validaInteiro(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.msgErrorDialog("Deve haver um inteiro como entrada.", "Erro");
			valor = validaInteiro(mensagem);
		}
		return valor;
	}
		public static float validaPreco(String mensagem) {
		float preco = validaFloat(mensagem);

		return preco;
	}
	private static float validaFloat(String mensagem) {
		float valor = -1f;

		try {
			valor = Float.parseFloat(Leitura.lerShowInputDialog(mensagem, "Valida Numero"));
			if (valor < 0) {
				Visao.msgErrorDialog("O valor deve ser positivo", "Erro");
				valor = validaFloat(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.msgErrorDialog("Deve haver uma entrada numerica.", "Erro");
			valor = validaFloat(mensagem);
		}
		return valor;
	}

	private static boolean isNomeComDigitos(String nome) {
		for (char c : nome.toCharArray()) {
			if (Character.isDigit(c)) {
				return true;
			}
		}
		return false;
	}

	private static int getPosicaoSelect(String[] select, String opc) {
		for (int i = 0; i < select.length; i++) {
			if (opc.equals(select[i])) {
				return (i+1);
			}
		}
		
		Visao.msgWarningDialog("A selecao eh obrigatoria.", "Aviso");
		return -1;
	}

}
