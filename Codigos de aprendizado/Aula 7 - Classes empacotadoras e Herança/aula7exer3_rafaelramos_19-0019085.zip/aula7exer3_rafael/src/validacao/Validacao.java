package validacao;

import java.util.InputMismatchException;

import leitura.Leitura;
import saida.Visao;

public class Validacao {

	private static int validaInteiro() {
		int valor;

		try {
			valor = Leitura.leiaInt();
			if (valor < 0) {
				Visao.mostraMsgErro("Erro, o valor deve ser positivo");
				valor = validaInteiro();
			}
		} catch (InputMismatchException e) {
			Visao.mostraMsgErro("Erro, a entrada deve ser numerica.");
			valor = validaInteiro();
		}
		return valor;
	}

	private static float validaFloat() {
		float valor;

		try {
			valor = Leitura.leiaFloat();
			if (valor < 0) {
				Visao.mostraMsgErro("Erro, o valor deve ser positivo");
				valor = validaFloat();
			}
		} catch (InputMismatchException e) {
			Visao.mostraMsgErro(
					"Erro, a entrada deve ser numerica e nao pode conter '.' separando os numeros com virgula.");
			valor = validaFloat();
		}
		return valor;
	}

	public static int validaAnoAmamentacao() {
		int anoAmamentacao;
		Visao.mostraMsg("Digite a idade de amamenta��o materna deste animal:");
		anoAmamentacao = validaInteiro();
		if (anoAmamentacao < 0 || anoAmamentacao > 10) {
			Visao.mostraMsgErro(
					"O ano de amamentacao materna deve pelo menos comecar em 0 e terminar no maximo em 10.");
			return validaAnoAmamentacao();
		}
		return anoAmamentacao;
	}

	public static int validaAnosVida() {
		int anosVida;
		Visao.mostraMsg("Digite a idade maxima deste animal:");
		anosVida = validaInteiro();
		if (anosVida < 0 || anosVida > 150) {
			Visao.mostraMsgErro(
					"Os anos maximos de vida deste animal deve pelo menos comecar em 0 e terminar no maximo em 150.");
			return validaAnosVida();
		}
		return anosVida;
	}

	public static String validaDescricao() {
		Visao.mostraMsg("Digite a descricao desse animal");
		String descricao = Leitura.leiaString();

		if (descricao.length() < 3) {
			Visao.mostraMsgErro("Erro, a descricao deve conter ao menos 3 caracteres.");
			descricao = validaDescricao();
		}

		return descricao;
	}

	public static float validaTamanho() {
		Visao.mostraMsg("Digite o tamanho deste animal na fase adulta (em metros):");
		float tamanho = Validacao.validaFloat();
		if (tamanho < 0 || tamanho > 30) {
			Visao.mostraMsgErro("Tamanho invalido, digite um tamanho entre (0 e 30 metros).");
			return validaTamanho();
		}
		return tamanho;
	}

	public static String validaPorte() {
		Visao.mostraMsg("Digite o porte do animal:\n[Pequeno]\n[Medio]\n[Grande]");
		String porte = Leitura.leiaString();
		if (!porte.equalsIgnoreCase("pequeno") && !porte.equalsIgnoreCase("medio") && !porte.equalsIgnoreCase("grande")
				|| porte.length() < 3) {
			Visao.mostraMsgErro("Erro, a entrada so pode ser: pequeno, medio ou grande e nao pode ser vazia");
			return validaPorte();
		}
		return porte;
	}

	public static float validaPeso() {
		Visao.mostraMsg("Digite o peso do animal (em kg)");
		float peso = Validacao.validaFloat();
		if (peso < 0) {
			Visao.mostraMsgErro("O peso do animal nao pode ser negativo");
			peso = validaPeso();
		}
		return peso;
	}

	public static String validaHabitat() {
		Visao.mostraMsg("Digite o habitat natural desse animal");
		String habitat = Leitura.leiaString();

		if (habitat.length() < 3) {
			Visao.mostraMsgErro("Erro, a descricao do habitat deve conter ao menos 3 caracteres.");
			habitat = validaDescricao();
		}

		return habitat;
	}

	public static char validaChar(String caracteresValidos) {
		char caracter;

		caracter = Leitura.leiaChar();
		while (!caracteresValidos.contains(Character.toString(caracter))) {
			Visao.mostraMsgErro("Entrada invalida! tente novamente");
			caracter = Leitura.leiaChar();
		}
		return caracter;
	}

	public static boolean validaCadastro(int numCadastros) {
		final int MAXIMO = 500;
		if (numCadastros <= MAXIMO) {
			Visao.mostraMsg(
					"Deseja cadastrar outro animal?\n[1] Cadastrar um novo animal.\n[0] Sair do programa listando os animais cadastrados.");
			return validaChar("01") == '1';
		} else
			return false;

	}

	public static char validaAnimal() {
		Visao.mostraMsg("Qual animal deseja cadastrar?\n[1] - Macaco\n[2] - Elefante\n[3] - Baleia");
		return validaChar("123");
	}

	private static boolean isNomeComNumeros(String nome) {
		for (char c : nome.toCharArray()) {
			if (Character.isDigit(c)) {
				return true;
			}
		}
		return false;
	}
}
