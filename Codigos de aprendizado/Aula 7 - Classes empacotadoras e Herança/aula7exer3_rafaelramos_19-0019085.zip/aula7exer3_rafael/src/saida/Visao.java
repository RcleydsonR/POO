package saida;

import dados.Animais;
import dados.Mamifero;

public class Visao {
	public static void mostraMsg(String mensagem) {
		System.out.println(mensagem);
	}

	public static void mostraMsgErro(String mensagem) {
		System.err.println(mensagem);
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

	public static void mostraTabela(Animais animais) {
		System.out.println(String.format("%-10s%-21s%-15s%-10s%-29s%-15s%-15s", "MAMIFERO |", " AMAMENTACAO(anos)  |",
				" IDADE MAXIMA |", " TAMANHO |", "        DESCRICAO", "| PORTE/PESO", "|   HABITAT"));
		System.out.println(
				"--------------------------------------------------------------------------------------------------------------------");
		for (Mamifero animal : animais.getListaAnimais()) {
			System.out.println(animal);
		}
	}
}
