package principal;

import dados.Animais;
import dados.Baleia;
import dados.Elefante;
import dados.Macaco;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {
		Animais animais = new Animais();
		char animal;
		do {
			animal = Validacao.validaAnimal();
			switch (animal) {
			case '1':
				animais.setMamifero(new Macaco(Validacao.validaAnoAmamentacao(), Validacao.validaAnosVida(),
						Validacao.validaDescricao(), Validacao.validaTamanho(), Validacao.validaPorte()));
				break;
			case '2':
				animais.setMamifero(new Elefante(Validacao.validaAnoAmamentacao(), Validacao.validaAnosVida(),
						Validacao.validaDescricao(), Validacao.validaTamanho(), Validacao.validaPeso(),
						Validacao.validaHabitat()));
				break;
			case '3':
				animais.setMamifero(new Baleia(Validacao.validaAnoAmamentacao(), Validacao.validaAnosVida(),
						Validacao.validaDescricao(), Validacao.validaTamanho(), Validacao.validaPeso()));
				break;
			default:
				continue;
			}
		} while (Validacao.validaCadastro(animais.getListaAnimais().size()));
		Visao.limpaTela(50);

		Visao.mostraTabela(animais);
	}
}
