package dados;

import java.text.DecimalFormat;

public class Elefante extends Mamifero {
	private Float peso;
	private String habitat;

	public Elefante(Integer anosAmamentacao, Integer anosVida, String descricao, Float tamanhoAdulto, Float peso,
			String habitat) {
		super(anosAmamentacao, anosVida, descricao, tamanhoAdulto);
		this.peso = peso;
		this.habitat = habitat;
	}

	public Float getPeso() {
		return peso;
	}

	public String getHabitat() {
		return habitat;
	}

	public String toString() {
		DecimalFormat mascara = new DecimalFormat("0.00");
		return "ELEFANTE |" + super.toString()
				+ String.format("%-3s%-12s%-20s", "|", mascara.format(this.peso) + " kg", "| " + this.habitat);
	}

}
