package dados;

public class Macaco extends Mamifero {
	private String porte;

	public Macaco(Integer anosAmamentacao, Integer anosVida, String descricao, Float tamanhoAdulto, String porte) {
		super(anosAmamentacao, anosVida, descricao, tamanhoAdulto);
		this.porte = porte;
	}

	public String getPorte() {
		return porte;
	}

	public String toString() {
		return "MACACO   |" + super.toString() + String.format("%-5s%-10s%-5s", "|", this.porte, "|");
	}

}
