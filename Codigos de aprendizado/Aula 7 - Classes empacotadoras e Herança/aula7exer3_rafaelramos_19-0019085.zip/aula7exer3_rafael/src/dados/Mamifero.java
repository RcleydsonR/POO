package dados;

import java.text.DecimalFormat;

public class Mamifero {
//ATRIBUTOS
	private Integer anosAmamentacao;
	private Integer anosVida;
	private String descricao;
	private Float tamanhoAdulto;

	public Mamifero(Integer anosAmamentacao, Integer anosVida, String descricao, Float tamanhoAdulto) {
		super();
		this.anosAmamentacao = anosAmamentacao;
		this.anosVida = anosVida;
		this.descricao = descricao;
		this.tamanhoAdulto = tamanhoAdulto;
	}

	public Integer getAnosAmamentacao() {
		return anosAmamentacao;
	}

	public void setAnosAmamentacao(Integer anosAmamentacao) {
		this.anosAmamentacao = anosAmamentacao;
	}

	public Integer getAnosVida() {
		return anosVida;
	}

	public void setAnosVida(Integer anosVida) {
		this.anosVida = anosVida;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Float getTamanhoAdulto() {
		return tamanhoAdulto;
	}

	public void setTamanhoAdulto(Float tamanhoAdulto) {
		this.tamanhoAdulto = tamanhoAdulto;
	}

	public String toString() {
		DecimalFormat mascara = new DecimalFormat("0.00");
		return String.format("%-5s%-15s%-15s%-10s%-30s", "", this.anosAmamentacao + " anos",
				"| " + this.anosVida + " anos", "| " + mascara.format(this.tamanhoAdulto) + " m",
				"| " + this.descricao);
	}

}
