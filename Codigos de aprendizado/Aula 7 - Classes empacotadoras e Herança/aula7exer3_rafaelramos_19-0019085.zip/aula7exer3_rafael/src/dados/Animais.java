package dados;

import java.util.ArrayList;

public class Animais {
	private ArrayList<Mamifero> listaAnimais;
	
	public Animais () {
		this.listaAnimais = new ArrayList<Mamifero>();
	}

	public ArrayList<Mamifero> getListaAnimais () {
		return listaAnimais;
	}

	public void setMamifero (Mamifero animal) {
		this.listaAnimais.add(animal);
	}
	
}
