package dados;

import java.text.DecimalFormat;

public class Baleia extends Mamifero {
	private Float peso;

	public Baleia(Integer anosAmamentacao, Integer anosVida, String descricao, Float tamanhoAdulto, Float peso) {
		super(anosAmamentacao, anosVida, descricao, tamanhoAdulto);
		this.peso = peso;
	}

	public Float getPeso() {
		return peso;
	}

	public String toString() {
		DecimalFormat mascara = new DecimalFormat("0.00");
		return "BALEIA   |" + super.toString()
				+ String.format("%-3s%-12s%-5s", "|", mascara.format(this.peso) + " kg", "|");
	}
}
