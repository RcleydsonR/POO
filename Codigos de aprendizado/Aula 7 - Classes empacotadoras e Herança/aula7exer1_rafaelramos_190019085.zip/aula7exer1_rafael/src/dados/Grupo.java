package dados;

import java.util.ArrayList;

public class Grupo {
	private ArrayList<Fatos_Ano> fatos_Anos;

	public Grupo() {
		fatos_Anos = new ArrayList<Fatos_Ano>();
	}

	public ArrayList<Fatos_Ano> getFatosAnos() {
		return this.fatos_Anos;
	}

	public Fatos_Ano getFatoAno(int numAno) {
		return fatos_Anos.get(numAno);
	}

	public void setFatosAnos(Fatos_Ano fatos_Ano) {
		this.fatos_Anos.add(fatos_Ano);
	}
}
