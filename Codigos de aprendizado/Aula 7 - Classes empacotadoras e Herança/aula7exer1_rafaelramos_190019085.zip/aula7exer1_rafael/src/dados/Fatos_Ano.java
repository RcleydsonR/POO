package dados;

import java.text.DecimalFormat;

public class Fatos_Ano {
	private Integer ano;
	private String nomePresidente;
	private String nomeEvento;

	public Fatos_Ano(int ano, String nomeEvento, String nomePresidente) {
		setAno(ano);
		setNomeEvento(nomeEvento);
		setNomePresidente(nomePresidente);
	}

	public String toString() {
		return (this.getAno() + "\t\t" + this.getNomeEvento() + "\t\t" + this.getNomePresidente());
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public String getNomePresidente() {
		return nomePresidente;
	}

	public void setNomePresidente(String nomePresidente) {
		this.nomePresidente = nomePresidente;
	}

	public String getNomeEvento() {
		return nomeEvento;
	}

	public void setNomeEvento(String nomeEvento) {
		this.nomeEvento = nomeEvento;
	}
}
