package principal;

import dados.*;
import saida.Saida;
import saida.Visao;
import validacao.Validacao;

public class Principal {
	public static void main(String[] args) {
		Grupo anos = new Grupo();

		do {
			anos.setFatosAnos(new Fatos_Ano(Validacao.validaAno(), Validacao.validaNome(0), Validacao.validaNome(1)));
			Visao.limpaTela(5);
		} while (Validacao.isContinuaCadastro());

		Saida.apresentaRelatorio(anos);
	}
}
