package validacao;

import java.util.ArrayList;
import java.util.InputMismatchException;
import dados.Fatos_Ano;
import dados.Grupo;
import leitura.Leitura;
import saida.Saida;
import saida.Visao;

public class Validacao {
	public static String validaNome(int aux) {
		String nome;

		if (aux == 0)
			Visao.solicitaNomeEvento();
		else
			Visao.solicitaNomePresidente();

		while ((nome = Leitura.leString()).isEmpty()) {
			Visao.mostraMensagem("A entrada nao pode ser vazia! Tente novamente");
		}
		return nome;
	}

	public static int validaAno() {
		int ano = 0;
		final int ano_min = 1900;
		final int ATUAL = 2020;

		do {
			try {
				Visao.solicitaAno();
				ano = Leitura.leInteiro();

				if (ano < ano_min || ano > ATUAL) {
					Visao.mostraMensagem("\nAno invalido !! Digite um ano entre " + ano_min + " e " + ATUAL + ".");
				}
			} catch (InputMismatchException e) {
				Visao.mostraMensagem("\nFormato de ano invalido !! Digite o ano em formato de numeros inteiros");
				continue;
			}
		} while (ano < ano_min || ano > ATUAL);

		return ano;
	}

	public static char validaChar(String caracteresValidos) {
		char caracter;

		caracter = Leitura.leCaracter();
		while (!caracteresValidos.contains(Character.toString(caracter))) {
			Visao.mostraMensagem("Entrada invalida! tente novamente");
			caracter = Leitura.leCaracter();
		}
		return caracter;
	}

	public static boolean isContinuaCadastro() {
		Visao.mostraMensagem("Deseja cadastrar um novo ano? 'S' para sim e 'N' para nao");
		return validaChar("SN") == 'S';
	}

}
