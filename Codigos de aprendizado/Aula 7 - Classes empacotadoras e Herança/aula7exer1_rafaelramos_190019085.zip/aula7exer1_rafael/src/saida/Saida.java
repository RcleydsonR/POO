package saida;

import dados.Grupo;
import validacao.Validacao;

public class Saida {
	public static void apresentaRelatorio(Grupo anos) {

		Visao.limpaTela(50);
		System.out.println("--------------------------------------------------------");
		System.out.println("ANO\t\tEVENTO\t\t\tPRESIDENTE");
		System.out.println("--------------------------------------------------------");

		for (int numAno = 0; numAno < anos.getFatosAnos().size(); numAno++) {
			System.out.println(anos.getFatoAno(numAno).toString());
		}
	}

}
