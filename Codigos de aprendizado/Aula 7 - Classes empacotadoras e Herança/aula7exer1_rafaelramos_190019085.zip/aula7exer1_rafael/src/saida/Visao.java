package saida;

public class Visao {
	public static void solicitaAno() {
		System.out.println("Digite o ano de referencia:");
	}

	public static void solicitaNomeEvento() {
		System.out.println("Digite o evento que ocorreu neste ano:");
	}

	public static void solicitaNomePresidente() {
		System.out.println("Digite o nome do presidente brasileiro neste ano:");
	}

	public static void mostraMensagem(String msg) {
		System.out.println(msg);
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}
}
