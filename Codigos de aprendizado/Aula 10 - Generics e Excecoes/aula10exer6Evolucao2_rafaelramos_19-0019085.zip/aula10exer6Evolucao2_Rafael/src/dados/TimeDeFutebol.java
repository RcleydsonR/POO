package dados;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TimeDeFutebol {
	private String nome;
	private List<AnoCampeao> listaAnosCampeao;

	public TimeDeFutebol(String pNome) {
		this.nome = pNome;
		this.listaAnosCampeao = new ArrayList<AnoCampeao>();
	}

	public void addAno(int ano) {
		this.listaAnosCampeao.add(new AnoCampeao(ano));
	}

	public String getNome() {
		return this.nome.toString();
	}

	public List<AnoCampeao> getAnosCampeao() {
		return this.listaAnosCampeao;
	}

	public boolean equals(TimeDeFutebol novoTime) {
		return this.nome.toUpperCase().equals(novoTime.getNome().toUpperCase());
	}
	
	public boolean contains(int novoAno) {
		for(AnoCampeao anoCampeao : this.listaAnosCampeao) {
			if(anoCampeao.equals(novoAno))
				return true;
		}
		return false;
	}

	public String toString() {
		String formato = "%-20s%-3s";
		StringBuilder str = new StringBuilder(String.format(formato, this.getNome().toUpperCase(), "|"));

		if (this.getAnosCampeao().size() == 0) {
			str.append("Ainda n�o foi campe�o brasileiro.");
		} else {
			Collections.sort(listaAnosCampeao);
			for (AnoCampeao anoC :  this.getAnosCampeao()) {
				str.append(anoC);
			}
		}

		return str.toString();
	}

	public class AnoCampeao implements Comparable<AnoCampeao> {
		private Integer anoCampeao;

		public AnoCampeao(Integer anoCampeao) {
			this.anoCampeao = anoCampeao;
		}

		public Integer getAnoCampeao() {
			return anoCampeao;
		}
		
		public String toString() {
			return String.format("%-7s", this.getAnoCampeao() + ";");
		}

		public boolean equals(Integer novoAno) {
			return this.getAnoCampeao().equals(novoAno);
		}

		public int compareTo(AnoCampeao novoAno) {
			return novoAno.getAnoCampeao().compareTo(getAnoCampeao());
		}

	}
}
