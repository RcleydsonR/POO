package dados;

import java.util.ArrayList;
import java.util.List;

public class GrupoTimes {
	private List<TimeDeFutebol> listaTimes;
	
	public GrupoTimes() {
		listaTimes = new ArrayList<TimeDeFutebol>();
	}

	public List<TimeDeFutebol> getListaTimes() {
		return listaTimes;
	}

	public void setTime(TimeDeFutebol time) {
		this.listaTimes.add(time);
	}
	
	public boolean contains(TimeDeFutebol timeNovo) {
		for(TimeDeFutebol time : this.getListaTimes()) {
			if(time.equals(timeNovo))
				return true;
		}
		return false;
	}
}
