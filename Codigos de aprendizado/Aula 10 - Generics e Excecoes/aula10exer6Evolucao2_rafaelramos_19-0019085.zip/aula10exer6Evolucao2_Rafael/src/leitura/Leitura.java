package leitura;

import javax.swing.JOptionPane;

public class Leitura {
	public static int perguntaConfirma(String msg, String titulo) {
		return JOptionPane.showConfirmDialog(null, msg, titulo, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	}

	public static String solicitaDado(String msg, String titulo) {
		return JOptionPane.showInputDialog(null, msg, titulo, JOptionPane.PLAIN_MESSAGE);
	}
	
	public static int lerOpcaoOrdenar(String[] opcoes) {
		return JOptionPane.showOptionDialog(null, "Selecione uma opcao de apresentacao:", "MENU DE SAIDA", 0, JOptionPane.INFORMATION_MESSAGE,
				null, opcoes, opcoes[0]);
	}
}
