package saida;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.JOptionPane;
import dados.GrupoTimes;
import dados.TimeDeFutebol;

class OrdenaNome implements Comparator<TimeDeFutebol> {
	public int compare(TimeDeFutebol time1, TimeDeFutebol time2) {
		return (time1.getNome().compareTo(time2.getNome()));
	}
}

public class Visao {
	public static void limpaTela(int n) {
		for (int i = 0; i < n; i++)
			System.out.println();
	}
	
	public static void mostraMensagemConsole(String msg) {
		limpaTela(5);
		System.out.println(msg);
	}
	
	public static void mostraMensagem(String msg, String titulo) {
		JOptionPane.showMessageDialog(null, msg, titulo, JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static void mostraErro(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Erro", JOptionPane.ERROR_MESSAGE);
	}
	
	public static void mostraTimesCadastro(GrupoTimes times) {
		mostraMensagemConsole(String.format("%-20s%-25s", "        TIME", "|      TITULOS CONQUISTADOS"));
		for(TimeDeFutebol time : times.getListaTimes())
			System.out.println(time);
	}
	
	public static void mostraTimesOrdenados(GrupoTimes times) {
		ArrayList<TimeDeFutebol> timesOrdenados = new ArrayList<TimeDeFutebol>(times.getListaTimes());
		mostraMensagemConsole(String.format("%-20s%-25s", "        TIME", "|      TITULOS CONQUISTADOS"));
		Collections.sort(timesOrdenados, new OrdenaNome());
		for(TimeDeFutebol time : timesOrdenados)
			System.out.println(time);
	}

}
