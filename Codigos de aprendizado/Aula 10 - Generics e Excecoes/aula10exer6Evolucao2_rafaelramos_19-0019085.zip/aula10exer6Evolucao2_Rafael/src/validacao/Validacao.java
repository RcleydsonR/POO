package validacao;

import dados.GrupoTimes;
import dados.TimeDeFutebol;
import leitura.Leitura;
import principal.Principal;
import saida.Visao;

public class Validacao {
	public static boolean validaContinua() {
		int opcao = Leitura.perguntaConfirma("Deseja cadastrar outro time?", "Cadastro de Time");
		return opcao == 0;
	}

	public static int validaMenuSaida() {
		String opcoes[] = { "Mostrar Times na ordem de cadastro", "Mostrar Times em ordem alfabetica",
				"Encerrar programa" };
		return Leitura.lerOpcaoOrdenar(opcoes);
	}

	public static String validaNome() {
		String nome;
			try {
			nome = Leitura.solicitaDado("Insira o nome do time:", "Cadastro de Time").trim();
			if (nome.isEmpty()) {
				Visao.mostraErro("Nome nao pode ser vazio");
				nome = validaNome();
			}}catch(NullPointerException ex) {
				Visao.mostraErro("Erro. N�o houve nome digitado. Tente novamente.");
				nome = validaNome();
			}

		return nome;
	}

	public static int validaAno(TimeDeFutebol time) {
		final int ANO_MIN = 1900, ANO_MAX = 2020;
		int ano = -1;

		try {
			ano = Integer.parseInt(
					Leitura.solicitaDado("Insira um ano em que o time foi campeao.", "Cadastro de Time").trim());

			if (ano <= ANO_MIN || ano >= ANO_MAX || time.contains(ano)) {
				Visao.mostraErro("O ano nao pode ser repetido e deve estar entre " + (ANO_MIN + 1) + " e " + (ANO_MAX - 1) + ".");
				ano = validaAno(time);
			}
		} catch (NumberFormatException ex) {
			Visao.mostraErro("Digite um numero.");
			ano = validaAno(time);
		}

		return ano;
	}

	public static boolean validaTitulo() {
		int opcao = Leitura.perguntaConfirma("Deseja cadastrar um/outro titulo?", "Cadastro de Time");
		return opcao == 0;
	}

	public static TimeDeFutebol criaTime(GrupoTimes times) {
		TimeDeFutebol timeNovo = new TimeDeFutebol(validaNome());
		if (times.contains(timeNovo)) {
			Visao.mostraErro("Time ja foi criado, tente novamente:");
			timeNovo = criaTime(times);
		}
		return timeNovo;
	}

	public static void registraTime(GrupoTimes times) {
		times.setTime(criaTime(times));
	}

	public static boolean cadastraTimes(GrupoTimes times) {
		int aux = 0;
		do {
				registraTime(times);
				Principal.qtdTimes++;
				while (Validacao.validaTitulo()) {
					times.getListaTimes().get(aux).addAno(Validacao.validaAno(times.getListaTimes().get(aux)));
				}
				aux++;
		} while (Validacao.validaContinua());
		return false;
	}

	public static boolean mostraMenuSaida(GrupoTimes times) {
		switch (Validacao.validaMenuSaida()) {
		case 0:
			Visao.mostraTimesCadastro(times);
			return true;
		case 1:
			Visao.mostraTimesOrdenados(times);
			return true;
		case 2:
			return false;
		default:
			return true;
		}
	}
}
