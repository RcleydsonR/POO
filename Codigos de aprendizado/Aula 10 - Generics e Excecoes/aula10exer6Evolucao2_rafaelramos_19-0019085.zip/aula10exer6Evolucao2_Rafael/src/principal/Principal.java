package principal;

import dados.GrupoTimes;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static int qtdTimes = 0;
	public static void main(String[] args) {
		GrupoTimes times = new GrupoTimes();
		
		while(Validacao.cadastraTimes(times));
		while(Validacao.mostraMenuSaida(times));
		
		Visao.mostraMensagemConsole("Numero de times cadastrados: " + qtdTimes);
	}
	
}
