package principal;

/** S�ntese
* Objetivo: guardar e mostrar dados de cidades
* Entrada: cidades e DDDs
* Sa�da: listagem das cidades cadastradas em ordem
*/
import java.util.ArrayList;

import dados.Cidade;
import saida.Visao;
import validacao.Validacao;

import java.util.*;

public class ArrayLista {
	
	public static void main(String[] args) {
		List<Cidade> listaCidades = new ArrayList<Cidade>();
		while(Validacao.exibirConfirmacao()) {
			listaCidades.add(Validacao.criaCidade(listaCidades));
		}

		Visao.mostraCidadesOrdenadas(listaCidades);
	}

}
