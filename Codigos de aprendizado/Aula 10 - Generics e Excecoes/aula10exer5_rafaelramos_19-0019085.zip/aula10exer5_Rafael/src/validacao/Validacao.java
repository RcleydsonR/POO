package validacao;

import java.util.List;

import dados.Cidade;
import leitura.Leitura;
import saida.Visao;

public class Validacao {
	public static boolean exibirConfirmacao() {
		int resposta = Leitura.leConfirmacao();
		return (resposta == 0 ? true : resposta == 1 ? false : exibirConfirmacao());
	}

	public static int validaDDD() {
		int ddd = 0;

			try {
				ddd = Integer.parseInt(Leitura.leRegistro("Digite o DDD desta cidade:"));
				if (ddd < 10 || ddd > 100) {
					Visao.msgErrorDialog("DDD invalido. Digite um DDD entre 10 e 100", "Erro");
					ddd = validaDDD();
				}
			} catch (Exception exc) {
				Visao.msgErrorDialog("o DDD deve ser um numero inteiro.", "Erro");
				ddd = validaDDD();
			}
		
		return ddd;
	}
	
	public static String validaNome() {
		String nome = Leitura.leRegistro("Digite o nome da cidade.");
		if(nome == null || nome.trim().length() < 3) {
			Visao.msgErrorDialog("Nome precisa ter pelo menos 3 caracteres", "Erro");
			nome = validaNome();
		}
		return nome;
	}
	
	public static Cidade criaCidade(List<Cidade> listaCidades) {
		Cidade novaCidade = new Cidade();
		novaCidade.setNome(validaNome());
		novaCidade.setDDD(validaDDD());
		
		for(Cidade cidade : listaCidades) {
			if(novaCidade.equals(cidade)) {
				Visao.msgErrorDialog("Esta cidade ja foi criada. Tente novamente", "Erro");
				novaCidade = criaCidade(listaCidades);
			}
		}
		return novaCidade;
	}
}
