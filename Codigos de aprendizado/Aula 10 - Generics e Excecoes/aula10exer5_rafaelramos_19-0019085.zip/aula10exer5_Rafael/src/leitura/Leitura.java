package leitura;

import javax.swing.JOptionPane;

public class Leitura {
	
	public static int leConfirmacao() {
	return JOptionPane.showConfirmDialog(null, "Deseja registrar uma cidade?", "Pergunta",
			JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);	
	}
	
	public static String leRegistro(String msg) {
		return JOptionPane.showInputDialog(null, msg, "Registro",
				JOptionPane.PLAIN_MESSAGE);
	}
	
}
