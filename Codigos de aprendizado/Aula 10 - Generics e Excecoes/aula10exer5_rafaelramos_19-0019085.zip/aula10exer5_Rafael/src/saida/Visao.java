package saida;

import java.util.List;
import java.util.Collections;

import javax.swing.JOptionPane;

import dados.Cidade;

public class Visao {
	
	public static void msgErrorDialog(String msg, String fieldset) {
		JOptionPane.showMessageDialog(null, msg, fieldset, JOptionPane.ERROR_MESSAGE);
	}
	
	public static void mostraCidadesOrdenadas(List<Cidade> listaCidades) {
		System.out.println("DDD\t|   Cidade\n=======================");
		
		Collections.sort(listaCidades);

		for (Cidade cidade : listaCidades) {
			System.out.println(cidade);
		}
	}

}
