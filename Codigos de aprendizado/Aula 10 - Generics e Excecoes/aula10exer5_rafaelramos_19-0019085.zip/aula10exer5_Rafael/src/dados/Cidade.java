package dados;

/** S�ntese
* Conte�do: nome da cidade, DDD
* - getNome(),getDDD(),setNome(String),setDDD(int)
* - toString(), compareTo(Object)
*/

public class Cidade implements Comparable<Object> {
	private String nome;
	private Integer DDD;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getDDD() {
		return DDD;
	}

	public void setDDD(int DDD) {
		this.DDD = DDD;
	}

	public String toString() {
		return ("" + this.getDDD() + "\t| " + this.getNome());
	}
	
	public boolean equals(Object obj) {
		Cidade novaCidade = (Cidade) obj;
		return (this.getNome().equalsIgnoreCase(novaCidade.getNome())
				&& this.getDDD().toString().equalsIgnoreCase(novaCidade.getDDD().toString()));
	}

	public int compareTo(Object objeto) {
		Cidade cidadeParametro = (Cidade) objeto;
		return (getDDD() > cidadeParametro.getDDD() ? 1 : getDDD() < cidadeParametro.getDDD() ? -1 : 0);
	}



}
