package visao;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import visao.leitura.Leitura;

@SuppressWarnings("serial")
public abstract class Tela extends JPanel {
	private String nomeTela;
	protected TelaPrincipal telaPrincipal;

	Tela(TelaPrincipal telaPrincipal, String nomeTela) {
		this.telaPrincipal = telaPrincipal;
		this.nomeTela = nomeTela;
	}

	public String getNomeTela() {
		return nomeTela;
	}

	protected void trocaTela(Tela tela) {
		telaPrincipal.removeTela(this);
		telaPrincipal.trocaTela(tela);
	}

	protected JButton criaBotao(String nomeBotao, String nomeImagem, int x, int y, int largura, int altura,
			String fonte) {
		JButton botao = new JButton(nomeBotao);
		botao.setFont(new Font(fonte, Font.PLAIN, 16));
		botao.setIcon(Leitura.leImagem(nomeImagem));
		botao.setBounds(x, y, largura, altura);
		super.add(botao);
		return botao;
	}

	protected JLabel criaLabel(String nomeLabel, int x, int y, int largura, int altura, String nomeFonte,
			int tamanhoFonte) {
		JLabel lbNew = new JLabel(nomeLabel);
		lbNew.setHorizontalAlignment(SwingConstants.CENTER);
		lbNew.setFont(new Font(nomeFonte, Font.PLAIN, tamanhoFonte));
		lbNew.setBounds(x, y, largura, altura);
		return lbNew;
	}

	protected JTextField criaCaixaTexto(int x, int y, int largura, int altura, String instrucao, int coluna) {
		JTextField novaCaixaTexto = new JTextField();
		novaCaixaTexto.setToolTipText(instrucao);
		novaCaixaTexto.setBounds(x, y, largura, altura);
		novaCaixaTexto.setColumns(coluna);

		return novaCaixaTexto;
	}

	protected void mudaLabelNome(JLabel label, String novoTexto, int opcaoCor) {
		label.setHorizontalAlignment(SwingConstants.LEADING);
		label.setForeground(opcaoCor == 0 ? Color.RED : opcaoCor == 1 ? Color.GREEN : Color.BLACK);
		label.setText(novoTexto);
	}

}
