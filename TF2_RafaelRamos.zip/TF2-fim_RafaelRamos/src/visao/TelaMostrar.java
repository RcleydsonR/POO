package visao;

import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import controle.ControladorLista;
import visao.validacao.Validacao;

@SuppressWarnings("serial")
public class TelaMostrar extends Tela {

	private JLabel lbInstrucao;
	private JLabel lbValidaID;
	private JTextField tfID;
	private JButton btnCancelar;
	private JButton btnMostrar;

	TelaMostrar(TelaPrincipal telaPrincipal) {
		super(telaPrincipal, "MOSTRAR");
		criaTelaMostrar();
		addAcoes();
	}

	private void criaTelaMostrar() {
		super.setBackground(UIManager.getColor("Button.highlight"));
		super.setLayout(null);

		lbInstrucao = criaLabel("Informe o ID da pessoa que deseja consultar:", 85, 110, 630, 60, "Times New Roman",
				15);
		super.add(lbInstrucao);

		lbValidaID = criaLabel("", 305, 200, 630, 20, "Times New Roman", 15);
		super.add(lbValidaID);

		tfID = criaCaixaTexto(305, 170, 190, 30, "Digite o ID da pessoa que deseja consultar", 10);
		super.add(tfID);
		btnMostrar = criaBotao("Mostrar", "search", 36, 344, 334, 61, "Trebuchet MS");
		btnMostrar.setEnabled(false);
		btnCancelar = criaBotao("Cancelar", "cancel", 410, 344, 334, 61, "Trebuchet MS");
	}

	private void addAcoes() {
		tfID.addCaretListener(e -> {
			if (Validacao.validaIdPesquisado(tfID.getText().trim())) {
				mudaLabelNome(lbValidaID, "ID valido!", 1);
				btnMostrar.setEnabled(true);
			} else {
				mudaLabelNome(lbValidaID, "ID invalida! Digite um ID maior que 100", 0);
				btnMostrar.setEnabled(false);
			}

		});
		btnMostrar.addActionListener(e -> mostraPessoaEspecifica(tfID.getText()));
		btnCancelar.addActionListener(e -> trocaTela(new TelaMenu(telaPrincipal)));
	}

	private void mostraPessoaEspecifica(String id) {
		ControladorLista controladorL = new ControladorLista();
		int idCadastro = Integer.parseInt(id.trim());
		try {
			String[] dadosPessoa = controladorL.getPessoaPesquisada(idCadastro);
			Visao.mostraPessoa(dadosPessoa);
		} catch (SQLException | NullPointerException e) {
			Visao.mostraMsg("ID nao encontrado.");
		}
	}
}
