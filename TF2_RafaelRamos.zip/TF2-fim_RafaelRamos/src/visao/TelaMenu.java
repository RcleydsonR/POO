package visao;

import java.awt.Color;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.UIManager;

import controle.ControladorLista;
import visao.leitura.Leitura;

@SuppressWarnings("serial")
public class TelaMenu extends Tela {

	private JButton btnNovo;
	private JButton btnListar;
	private JButton btnMostrar;
	private JButton btnPesquisar;
	private JButton btnSair;
	private JLabel lbImgMenu;

	public TelaMenu(TelaPrincipal telaPrincipal) {
		super(telaPrincipal, "MENU");

		criaPainelMenu();
		addAcoes();
	}

	private void criaPainelMenu() {
		super.setBackground(UIManager.getColor("Button.highlight"));
		super.setForeground(Color.BLUE);
		super.setLayout(null);

		btnNovo = criaBotao("Novo Cadastro", "user", 10, 10, 330, 60, "Times New Roman");
		btnListar = criaBotao("Listar", "usuarios", 10, 100, 330, 60, "Times New Roman");
		btnMostrar = criaBotao("Mostrar", "search", 10, 185, 330, 60, "Times New Roman");
		btnPesquisar = criaBotao("Pesquisar", "search", 10, 265, 330, 60, "Times New Roman");
		btnSair = criaBotao("Sair", "exit", 10, 350, 330, 60, "Times New Roman");

		lbImgMenu = new JLabel("");
		lbImgMenu.setIcon(Leitura.leImagem("pandemic"));
		lbImgMenu.setBounds(400, 10, 370, 400);
		super.add(lbImgMenu);
	}

	private void addAcoes() {
		btnNovo.addActionListener(e -> trocaTela(new TelaCadastro(super.telaPrincipal)));
		btnListar.addActionListener(e -> mudaTelaListar('l'));
		btnMostrar.addActionListener(e -> trocaTela(new TelaMostrar(telaPrincipal)));
		btnPesquisar.addActionListener(e -> mudaTelaListar('p'));
		btnSair.addActionListener(e -> {
			sairTela();
		});

	}

	private void mudaTelaListar(char opcaoTela) {
		try {
			ControladorLista controladorL = new ControladorLista();
			if (controladorL.getDadosPopulacao().getPopulacao().size() == 0)
				Visao.mostraMsg("NAO HA NENHUM CADASTRO");
			else
				super.trocaTela(new TelaListar(telaPrincipal, opcaoTela));
		} catch (SQLException | NullPointerException e) {
			Visao.mostraMsgErro("Impossivel se conectar com BD. ");
		}
	}

	private void sairTela() {
		try {
			ControladorLista controladorL = new ControladorLista();
			Visao.mostraAnaliseContaminados(controladorL.getDadosPopulacao());
			Visao.mostraTotalCadastro(controladorL.getDadosPopulacao());
		} catch (SQLException | NullPointerException e) {
			Visao.mostraMsgErro("Impossivel fazer analise dos dados. Nao houve conexao com o BD.");
		}
		telaPrincipal.dispose();
	}
}
