package visao.validacao;

public class Validacao {

	public static boolean isNome(String nome, int tamanho) {
		return (nome != null && nome.trim().length() > tamanho && nome.trim().length() <= 90
				&& !isNomeNaoAlfabetico(nome.trim()));
	}

	private static boolean isNomeNaoAlfabetico(String nome) {
		for (char c : nome.toCharArray()) {
			if (!Character.isLetter(c) && c != ' ') {
				return true;
			}
		}
		return false;
	}

	public static boolean validaIdade(String inteiro) {
		int idade;
		try {
			idade = Integer.parseInt(inteiro.trim());
			return isIdadeCorreta(idade);
		} catch (NumberFormatException | NullPointerException e) {
			return false;
		}
	}

	private static boolean isIdadeCorreta(int idade) {
		final int MAXIMO = 150;
		return (idade >= 0 && idade <= MAXIMO);
	}

	public static boolean validaIdPesquisado(String numero) {
		int valor;
		try {
			valor = Integer.parseInt(numero.trim());
			return isIdCorreto(valor);
		} catch (NumberFormatException | NullPointerException e) {
			return false;
		}
	}

	private static boolean isIdCorreto(int id) {
		return id >= 100;
	}
}
