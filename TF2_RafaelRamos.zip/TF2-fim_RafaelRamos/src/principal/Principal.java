package principal;

import visao.TelaPrincipal;

public class Principal {

	public static void main(String[] args) {
		TelaPrincipal telaPrincipal = new TelaPrincipal();
		telaPrincipal.setVisible(true);
	}

}
