package modelo.dados;

import java.util.ArrayList;
import java.util.List;

public class Populacao {

	private List<Pessoa> populacao;

	public Populacao() {
		this.populacao = new ArrayList<Pessoa>();
	}

	public List<Pessoa> getPopulacao() {
		return populacao;
	}

	public void setPessoa(Pessoa pessoa) {
		this.populacao.add(pessoa);
	}
	
	public int[] calculaContaminados() {
		int contaminados[] = new int[5];

		/*
		 * CONTAMINADOS[0] = PESSOA CONTAMINADA CURADA
		 * CONTAMINADOS[1] = PESSOA CONTAMINADA EM TRATAMENTO
		 * CONTAMINADOS[2] = PESSOA CONTAMINADA QUE FALECEU
		 * CONTAMINADOS[3] = HOMEM SEM CONTAMINACAO 
		 * CONTAMINADOS[4] = MULHER SEM CONTAMINACAO
		 */

		for (Pessoa pessoa : getPopulacao()) {
			String atributos[] = pessoa.toString().split("/");
			if (atributos[4].trim().equals("-")) {
				if (pessoa.getSaude() == 'C') {
					contaminados[0]++;
				} else if (pessoa.getSaude() == 'T') {
					contaminados[1]++;
				} else if (pessoa.getSaude() == 'F')
					contaminados[2]++;
				else
					contaminados[3]++;
			} else if (atributos[3].trim().equals("-")) {
				if (pessoa.getSaude() == 'C') {
					contaminados[0]++;
				} else if (pessoa.getSaude() == 'T') {
					contaminados[1]++;
				} else if (pessoa.getSaude() == 'F')
					contaminados[2]++;
				else
					contaminados[4]++;
			}

		}
		return contaminados;
	}
}
