package modelo.dados;

public class Pessoa {
	private StringBuilder nomeCompleto;
	private Integer numCadastro;
	private Character saude;

	public Pessoa(String nome, Character saude) {
		this.nomeCompleto = new StringBuilder(nome);
		setSaude(saude);
	}

	public StringBuilder getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(StringBuilder nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public void setNumCadastro(Integer numCadastro) {
		this.numCadastro = numCadastro;
	}

	public Integer getNumCadastro() {
		return numCadastro;
	}

	public Character getSaude() {
		return saude;
	}

	public void setSaude(Character saude) {
		this.saude = saude;
	}
}
