package modelo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import modelo.dados.Homem;
import modelo.dados.Mulher;
import modelo.dados.Pessoa;
import modelo.dados.Populacao;

public class PessoaDAO {

	private Connection con;

	public PessoaDAO() throws SQLException, NullPointerException {
		this.con = Conexao.getConnection();
	}

	public void cadastrar(Homem homem) throws SQLException , NullPointerException{
		String sql = "INSERT INTO pessoa (nome,saude, gestante, idade) VALUES (?, ?, ?, ?)";
		try {
			PreparedStatement preparador = con.prepareStatement(sql);
			preparador.setString(1, homem.getNomeCompleto().toString());
			preparador.setString(2, homem.getSaude().toString());
			preparador.setString(3, null);
			preparador.setInt(4, homem.getIdade());
			preparador.execute();
			preparador.close();
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					System.out.print("Falha ao fechar a conex�o.");
					System.out.println("Causa: " + e.getMessage());
				}
		}
	}

	public void cadastrar(Mulher mulher) throws SQLException, NullPointerException {
		String sql = "INSERT INTO pessoa (nome,saude, gestante, idade) VALUES (?, ?, ?, ?)";
		try {
			PreparedStatement preparador = con.prepareStatement(sql);
			preparador.setString(1, mulher.getNomeCompleto().toString());
			preparador.setString(2, mulher.getSaude().toString());
			preparador.setString(3, mulher.getGestante().toString());
			preparador.setString(4, null);
			preparador.execute();
			preparador.close();
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					System.out.print("Falha ao fechar a conex�o.");
					System.out.println("Causa: " + e.getMessage());
				}
		}
	}

	public Populacao getPopulacao() throws SQLException, NullPointerException {
		Populacao populacao = new Populacao();
		String sqlLista = "SELECT * FROM PESSOA";
		PreparedStatement preparador = con.prepareStatement(sqlLista);
		ResultSet lista = preparador.executeQuery();

		while (lista.next()) {
			populacao.setPessoa(registraPessoa(lista));
		}
		preparador.close();
		lista.close();
		fechaConexao();

		return populacao;
	}

	public void fechaConexao() throws SQLException {
		if (con != null)
			con.close();
	}

	public Pessoa registraPessoa(ResultSet lista) throws SQLException {
		if (lista.getString("gestante") == null)
			return registraHomem(lista);
		else
			return registraMulher(lista);
	}

	private Mulher registraMulher(ResultSet lista) throws SQLException {
		Mulher mulher = new Mulher(lista.getString("nome"), lista.getString("saude").charAt(0),
				lista.getString("gestante").charAt(0));
		mulher.setNumCadastro(lista.getInt("idPessoa"));
		return mulher;
	}

	private Homem registraHomem(ResultSet lista) throws SQLException {
		Homem homem = new Homem(lista.getString("nome"), lista.getString("saude").charAt(0), lista.getInt("idade"));
		homem.setNumCadastro(lista.getInt("idPessoa"));
		return homem;
	}

	public String[] getPessoaEspecifica(int id) throws SQLException {
		String[] dadosPessoa = new String[5];
		String sqlMostra = "SELECT * FROM PESSOA WHERE idPessoa = " + id;
		PreparedStatement preparador = con.prepareStatement(sqlMostra);
		ResultSet pes = preparador.executeQuery();

		pes.next();
		dadosPessoa[0] = pes.getString("idPessoa");
		dadosPessoa[1] = pes.getString("nome");
		dadosPessoa[2] = pes.getString("saude");
		dadosPessoa[3] = pes.getString("gestante");
		dadosPessoa[4] = pes.getString("idade");

		preparador.close();
		pes.close();
		fechaConexao();
		return dadosPessoa;

	}
}
