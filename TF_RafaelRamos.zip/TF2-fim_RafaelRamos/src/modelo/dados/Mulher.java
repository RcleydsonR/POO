package modelo.dados;

public class Mulher extends Pessoa {
	private Character gestante;

	public Mulher(String nome, Character saude, Character gestante) {
		super(nome, saude);
		this.gestante = gestante;
	}

	public Character getGestante() {
		return gestante;
	}

	public void setGestante(Character gestante) {
		this.gestante = gestante;
	}

	public String toString() {
		return (this.getNumCadastro() + "/ " + this.getNomeCompleto().toString().toLowerCase() + "/"
				+ (this.getSaude() == 'T' ? "contaminada em tratamento"
						: (this.getSaude() == 'F' ? "contaminada falecida"
								: (this.getSaude() == 'C' ? "contaminada curada" : "sem contaminacao")))
				+ "/     -" + "/ "
				+ (this.getGestante() == 'S' ? "sim" : (this.getGestante() == 'N' ? "nao" : "nao tem certeza")));

	}
}
