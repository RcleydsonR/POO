package visao;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

import modelo.dados.Populacao;

public class Visao {

	public static void mostraMsgConsole(String mensagem) {
		System.out.println(mensagem);
	}

	public static void mostraErroConsole(String mensagem) {
		System.err.println(mensagem);
	}

	public static void mostraMsg(String mensagem) {
		JOptionPane.showMessageDialog(null, mensagem);
	}

	public static void mostraMsgErro(String mensagem) {
		JOptionPane.showMessageDialog(null, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
		;
	}

	public static void mostraMsgConsulta(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Consulta ID", JOptionPane.PLAIN_MESSAGE);
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

	public static void mostraPessoa(String[] dadosPessoa) {
		try {
			if (dadosPessoa[3] == null) {
				mostraHomem(dadosPessoa);
			} else {
				mostraMulher(dadosPessoa);
			}
		} catch (NullPointerException e) {
		}

	}

	private static void mostraHomem(String[] dadosPessoa) {
		mostraMsgConsulta("ID: " + dadosPessoa[0] + "\nNome: " + dadosPessoa[1].toUpperCase() + "\nSaude: "
				+ separaSaude(dadosPessoa[2].charAt(0)) + "\nIdade: " + dadosPessoa[4]);
	}

	private static void mostraMulher(String[] dadosPessoa) {
		mostraMsgConsulta("ID: " + dadosPessoa[0] + "\nNome: " + dadosPessoa[1].toUpperCase() + "\nSaude: "
				+ separaSaude(dadosPessoa[2].charAt(0)) + "\nGestante: " + separaGestante(dadosPessoa[3].charAt(0)));
	}

	private static String separaSaude(char saude) {
		return (saude == 'T' ? "Contaminado(a) em tratamento"
				: (saude == 'F' ? "Contaminado(a) falecido(a)"
						: (saude == 'C' ? "Contaminado(a) curado(a)" : "Sem contaminacao")));
	}

	private static String separaGestante(char gestante) {
		return (gestante == 'S' ? "Sim" : (gestante == 'N' ? "Nao" : "Nao tem certeza"));
	}

	public static void mostraAnaliseContaminados(Populacao populacao) {
		int contaminados[] = populacao.calculaContaminados();
		DecimalFormat mascara = new DecimalFormat("00");
		limpaTela(20);
		mostraMsgConsole("\t\t\t\t\t" + mascara.format(contaminados[0]) + " = CONTAMINADOS(AS) CURADOS(AS)");
		mostraMsgConsole("\t\t\t\t\t" + mascara.format(contaminados[1]) + " = CONTAMINADOS(AS) EM TRATAMENTO");
		mostraMsgConsole("\t\t\t\t\t" + mascara.format(contaminados[2]) + " = CONTAMINADOS(AS) FALECIDOS(AS)");
		mostraMsgConsole("\t\t\t\t\t" + mascara.format(contaminados[3]) + " = HOMENS SEM CONTAMINACAO");
		mostraMsgConsole("\t\t\t\t\t" + mascara.format(contaminados[4]) + " = MULHERES SEM CONTAMINACAO");
	}

	public static void mostraTotalCadastro(Populacao populacao) {
		DecimalFormat mascara = new DecimalFormat("00");
		mostraErroConsole(
				"\t\t\t\t\t" + mascara.format(populacao.getPopulacao().size()) + " = TOTAL DE REGISTRO DE PESSOAS");
	}
}
