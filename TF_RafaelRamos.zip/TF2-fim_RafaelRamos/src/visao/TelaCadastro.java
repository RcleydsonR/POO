package visao;

import java.awt.CardLayout;
import java.awt.Font;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import controle.ControladorCadastro;
import visao.validacao.Validacao;

@SuppressWarnings("serial")
public class TelaCadastro extends Tela {

	private JPanel panelPessoa;
	private JPanel sexoPanel;
	private JPanel panelHomem;
	private JPanel panelMulher;
	private JLabel lbNome;
	private JLabel lbTitulo;
	private JLabel lbSituacaoDeSaude;
	private JLabel lbSexo;
	private JLabel lbIdade;
	private JLabel lbJaFoiGestante;
	private JLabel lbValidaNome;
	private JLabel lbValidaIdade;
	private JTextField tfNome;
	private JTextField tfIdade;
	private JComboBox<String> saudeComboBox;
	private JComboBox<String> sexoComboBox;
	private JComboBox<String> gestanteComboBox;
	private JButton btnSalvar;
	private JButton btnCancelar;

	public TelaCadastro(TelaPrincipal telaPrincipal) {
		super(telaPrincipal, "CADASTRO");
		criaPainelCadastro();
		addAcoes();
	}

	private void criaPainelCadastro() {
		super.setBackground(UIManager.getColor("Button.highlight"));
		super.setLayout(null);

		lbNome = criaLabel("Nome Completo:", 65, 30, 110, 30, "Times New Roman", 16);
		lbTitulo = criaLabel("CADASTRO DE PESSOA", 0, 0, 785, 40, "Trebuchet MS", 21);
		lbSituacaoDeSaude = criaLabel("Situacao de Saude", 295, 133, 401, 32, "Times New Roman", 16);
		lbValidaNome = criaLabel("", 65, 85, 500, 32, "Trebuchet MS", 12);
		super.add(lbNome);
		super.add(lbTitulo);
		super.add(lbSituacaoDeSaude);
		super.add(lbValidaNome);

		tfNome = criaCaixaTexto(65, 60, 630, 30, "Digite o nome completo da pessoa a ser cadastrada", 10);
		super.add(tfNome);

		saudeComboBox = criaComboBox(295, 170, 401, 25, "Escolha a Situacao de saude da pessoa a ser cadastrada\r\n",
				"Contaminado(a) em Tratamento", "Contaminado(a) Falecido(a)", "Contaminado(a) Curado(a)",
				"Sem contaminacao");
		super.add(saudeComboBox);

		btnSalvar = criaBotao("Salvar Cadastro", "save", 65, 375, 265, 40, "Trebuchet MS");
		btnSalvar.setEnabled(false);
		btnCancelar = criaBotao("Cancelar", "cancel", 435, 375, 265, 40, "Trebuchet MS");

		sexoPanel = new JPanel(null);
		sexoPanel.setBackground(UIManager.getColor("Button.highlight"));
		sexoPanel.setForeground(UIManager.getColor("Button.highlight"));
		sexoPanel.setBounds(65, 140, 209, 57);
		super.add(sexoPanel);

		sexoComboBox = criaComboBox(0, 30, 209, 25, "Selecione o sexo da pessoa a ser cadastrada", "Masculino",
				"Feminino");
		sexoPanel.add(sexoComboBox);

		lbSexo = criaLabel("Sexo", 0, 5, 209, 25, "Times New Roman", 16);
		sexoPanel.add(lbSexo);

		panelPessoa = new JPanel(new CardLayout(0, 0));
		panelPessoa.setBackground(UIManager.getColor("Button.highlight"));
		panelPessoa.setBounds(65, 245, 318, 71);
		super.add(panelPessoa);

		panelHomem = new JPanel(null);
		panelHomem.setBackground(UIManager.getColor("Button.highlight"));
		panelPessoa.add(panelHomem, "HOMEM");

		lbIdade = criaLabel("Idade em anos:", 0, 10, 100, 20, "Times New Roman", 16);
		panelHomem.add(lbIdade);

		tfIdade = criaCaixaTexto(110, 8, 100, 29, "Digite a idade desta pessoa (0 a 150)", 10);
		panelHomem.add(tfIdade);

		lbValidaIdade = criaLabel("", 43, 42, 223, 29, "Trebuchet MS", 12);
		panelHomem.add(lbValidaIdade);

		panelMulher = new JPanel(null);
		panelMulher.setBackground(UIManager.getColor("Button.highlight"));
		panelPessoa.add(panelMulher, "MULHER");

		lbJaFoiGestante = criaLabel("Ja foi gestante ?", 0, 10, 100, 20, "Times New Roman", 16);
		panelMulher.add(lbJaFoiGestante);

		gestanteComboBox = criaComboBox(110, 8, 190, 27,
				"Selecione a opcao referente a condicao de gestante da mulher.", "Sim", "Nao", "Nao tem certeza");
		panelMulher.add(gestanteComboBox);
	}

	private JComboBox<String> criaComboBox(int x, int y, int largura, int altura, String dica, String... opcoes) {
		JComboBox<String> novaComboBox = new JComboBox<String>(opcoes);
		novaComboBox.setBounds(x, y, largura, altura);
		novaComboBox.setToolTipText(dica);
		novaComboBox.setBackground(UIManager.getColor("ComboBox.disabledBackground"));
		novaComboBox.setForeground(UIManager.getColor("CheckBox.foreground"));
		novaComboBox.setFont(new Font("Comic Sans MS", Font.BOLD, 14));

		return novaComboBox;
	}

	private void mudaTelaPessoa(String tela) {
		CardLayout layout = (CardLayout) panelPessoa.getLayout();
		layout.show(panelPessoa, tela);
	}

	public char getSaude() {
		int saude = this.saudeComboBox.getSelectedIndex();
		return (saude == 0 ? 'T' : saude == 1 ? 'F' : saude == 2 ? 'C' : 'S');
	}

	public char getGestante() {
		int gestante = this.gestanteComboBox.getSelectedIndex();
		return (gestante == 0 ? 'S' : gestante == 1 ? 'N' : 'T');
	}

	public int getIdade() {
		return Integer.parseInt(tfIdade.getText().trim());
	}

	private void addAcoes() {

		sexoComboBox.addActionListener(e -> {
			if (sexoComboBox.getSelectedIndex() == 0) {
				mudaTelaPessoa("HOMEM");
				tfIdade.setText("");
				btnSalvar.setEnabled(false);
			} else {
				mudaTelaPessoa("MULHER");
				if (Validacao.isNome(tfNome.getText(), 2))
					btnSalvar.setEnabled(true);
			}
		});

		tfNome.addCaretListener(e -> {
			if (Validacao.isNome(tfNome.getText(), 2)) {
				mudaLabelNome(lbValidaNome, "Nome valido!", 1);
				if (sexoComboBox.getSelectedIndex() == 0) {
					if (Validacao.validaIdade(tfIdade.getText()))
						btnSalvar.setEnabled(true);
				} else
					btnSalvar.setEnabled(true);
			} else {
				mudaLabelNome(lbValidaNome, "Nome invalido! Digite um nome entre 3 e 90 caracteres e sem digitos.", 0);
				btnSalvar.setEnabled(false);
			}

		});

		tfIdade.addCaretListener(e -> {
			if (Validacao.validaIdade(tfIdade.getText().trim())) {
				mudaLabelNome(lbValidaIdade, "Idade valida!", 1);
				if (Validacao.isNome(tfNome.getText(), 2))
					btnSalvar.setEnabled(true);
			} else {
				mudaLabelNome(lbValidaIdade, "Idade invalida! Idade entre 0 e 150", 0);
				btnSalvar.setEnabled(false);
			}

		});

		btnSalvar.addActionListener((e -> {
			ControladorCadastro controlador = new ControladorCadastro();
			if (sexoComboBox.getSelectedIndex() == 0) {
				try {
					controlador.cadastrarHomem(tfNome.getText().trim(), getSaude(), getIdade());
					Visao.mostraMsg("Homem cadastrado com sucesso.");
				} catch (SQLException | NullPointerException e1) {
					Visao.mostraMsgErro("Erro, Nao ha conexao com o BD.");
				}

				trocaTela(new TelaMenu(super.telaPrincipal));

			} else {
				try {
					controlador.cadastrarMulher(tfNome.getText().trim(), getSaude(), getGestante());
					Visao.mostraMsg("Mulher cadastrada com sucesso.");
				} catch (SQLException | NullPointerException e2) {
					Visao.mostraMsgErro("Erro, Nao ha conexao com o BD.");
				}
				trocaTela(new TelaMenu(telaPrincipal));
			}
		}));

		btnCancelar.addActionListener(e -> trocaTela(new TelaMenu(telaPrincipal)));
	}

}