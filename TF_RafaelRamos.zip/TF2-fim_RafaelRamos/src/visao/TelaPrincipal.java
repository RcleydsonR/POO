package visao;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

import visao.leitura.Leitura;

@SuppressWarnings("serial")
public class TelaPrincipal extends JFrame {

	protected JPanel painelPrincipal;
	protected JPanel cabecalho;

	public TelaPrincipal() {
		super("COVID-19");
		criaTelaPrincipal();
	}

	private void criaTelaPrincipal() {
		this.setTitle("COVID 19 - PANDEMIA");
		this.getContentPane().setBackground(UIManager.getColor("Button.highlight"));
		this.setResizable(false);
		this.setSize(new Dimension(800, 600));
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.getContentPane().setLayout(null);

		criaPainelPrincipal();
		criaCabecalho();
	}

	private void criaPainelPrincipal() {
		painelPrincipal = new JPanel(new CardLayout());
		painelPrincipal.setBackground(UIManager.getColor("Button.highlight"));
		painelPrincipal.setBounds(0, 130, 785, 430);
		this.getContentPane().add(painelPrincipal, BorderLayout.CENTER);
		painelPrincipal.add(new JPanel());
		trocaTela(new TelaMenu(this));
	}

	private void criaCabecalho() {
		cabecalho = new JPanel(null);
		cabecalho.setBackground(UIManager.getColor("Button.highlight"));
		cabecalho.setBounds(0, 0, 795, 120);
		this.getContentPane().add(cabecalho, BorderLayout.NORTH);

		JLabel imgCabecalho = new JLabel("");
		imgCabecalho.setIcon(Leitura.leImagem("COVID19"));
		imgCabecalho.setBounds(0, 0, 790, 120);
		cabecalho.add(imgCabecalho);
	}

	public void trocaTela(String nomeTela) {
		CardLayout layout = (CardLayout) painelPrincipal.getLayout();
		layout.show(painelPrincipal, nomeTela);
	}

	public void trocaTela(Tela tela) {
		painelPrincipal.add(tela, tela.getNomeTela());
		trocaTela(tela.getNomeTela());
	}

	public void removeTela(Tela tela) {
		painelPrincipal.remove(tela);
	}

}
