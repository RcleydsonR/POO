package visao;

import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

import controle.ControladorLista;
import visao.validacao.Validacao;

@SuppressWarnings("serial")
public class TelaListar extends Tela {

	private JScrollPane tabelaScroll;
	private JLabel lbTitulo;
	private JLabel lbPesquisa;
	private JLabel lbQtdPesquisa;
	private JTextField tfPesquisa;
	private JTable tabelaDados;
	private JButton btnVoltar;
	private JButton btnPesquisar;
	private int registrosRecuperados;

	TelaListar(TelaPrincipal telaPrincipal, char opcaoTabela) throws SQLException {
		super(telaPrincipal, "LISTAR");
		criaPainelListar(opcaoTabela);
		criaTabela(opcaoTabela);
		addAcoes(opcaoTabela);
	}

	private void criaPainelListar(char opcaoTabela) {
		super.setBackground(UIManager.getColor("Button.highlight"));
		super.setLayout(null);
		criaScrollPane();
		btnVoltar = criaBotao("Voltar para o Menu", "cancel", 0, 380, 785, 50, "Trebuchet MS");
		switch (opcaoTabela) {
		case 'l':
			lbTitulo = criaLabel("LISTA DE PESSOAS CADASTRADAS", 0, 0, 785, 50, "Trebuchet MS", 22);
			super.add(lbTitulo);
			break;
		default:
			lbPesquisa = criaLabel("Digite o nome para pesquisa:", 0, 0, 600, 15, "Trebuchet MS", 12);
			super.add(lbPesquisa);
			tfPesquisa = criaCaixaTexto(20, 20, 550, 25, "Digite o nome ou fragmento de nome que deseja pesquisar", 10);
			super.add(tfPesquisa);
			btnPesquisar = criaBotao("Pesquisar", "search", 580, 20, 125, 25, "Trebuchet MS");
			lbQtdPesquisa = criaLabel("", 0, 320, 600, 20, "Trebuchet MS", 15);
			super.add(lbQtdPesquisa);
		}
	}

	public void criaScrollPane() {
		tabelaScroll = new JScrollPane();
		tabelaScroll.setBounds(0, 60, 785, 250);
		super.add(tabelaScroll);
	}

	private void criaTabela(char opcaoTabela) throws SQLException {
		String[] cabecalhoTabela = new String[] { "ID", "NOME COMPLETO", "SITUACAO DE SAUDE", "IDADE", "GESTANTE" };
		tabelaDados = new JTable();
		if (opcaoTabela == 'l') {
			tabelaDados.setModel(new DefaultTableModel(getDadosTabela(), cabecalhoTabela));
			tabelaDados.getColumnModel().getColumn(0).setPreferredWidth(30);
			tabelaDados.getColumnModel().getColumn(1).setPreferredWidth(250);
			tabelaDados.getColumnModel().getColumn(2).setPreferredWidth(150);
			tabelaDados.getColumnModel().getColumn(3).setPreferredWidth(30);
			tabelaDados.getColumnModel().getColumn(4).setPreferredWidth(50);
		}
		tabelaDados.setEnabled(false);
		tabelaScroll.setViewportView(tabelaDados);
		tabelaDados.getParent().setBackground(UIManager.getColor("Table.light"));
		tabelaDados.setBackground(UIManager.getColor("Button.highlight"));
	}

	private void modificaTabela(String nomePesquisado) throws SQLException {
		String[] cabecalhoTabela = new String[] { "ID", "NOME COMPLETO", "SITUACAO DE SAUDE", "IDADE", "GESTANTE" };
		tabelaDados.setModel(new DefaultTableModel(getDadosPesquisa(nomePesquisado), cabecalhoTabela));
		tabelaDados.getColumnModel().getColumn(0).setPreferredWidth(30);
		tabelaDados.getColumnModel().getColumn(1).setPreferredWidth(250);
		tabelaDados.getColumnModel().getColumn(2).setPreferredWidth(150);
		tabelaDados.getColumnModel().getColumn(3).setPreferredWidth(30);
		tabelaDados.getColumnModel().getColumn(4).setPreferredWidth(50);
	}

	public void limpaTabela(JTable tabelaDados) {
		DefaultTableModel exemplo = (DefaultTableModel) tabelaDados.getModel();
		for (int aux = 0; aux < tabelaDados.getRowCount(); aux++)
			exemplo.removeRow(aux);
	}

	private String[][] getDadosTabela() throws SQLException {
		ControladorLista controladorL = new ControladorLista();
		String[][] dadosPessoa = new String[controladorL.getDadosPopulacao().getPopulacao().size()][5];
		for (int contador = 0; contador < controladorL.getDadosPopulacao().getPopulacao().size(); contador++)
			dadosPessoa[contador] = controladorL.getDadosPopulacao().getPopulacao().get(contador).toString().split("/");
		return dadosPessoa;
	}

	private String[][] getDadosPesquisa(String nomePesquisado) throws SQLException {
		ControladorLista controladorL = new ControladorLista();
		registrosRecuperados = controladorL.getPopulacaoPesquisada(nomePesquisado).getPopulacao().size();
		if (registrosRecuperados == 0) {
			Visao.mostraMsg("Nenhum resultado encontrado");
			limpaTabela(tabelaDados);
		}
		String[][] dadosPessoa = new String[registrosRecuperados][5];
		for (int contador = 0; contador < registrosRecuperados; contador++)
			dadosPessoa[contador] = controladorL.getPopulacaoPesquisada(nomePesquisado).getPopulacao().get(contador)
					.toString().split("/");
		return dadosPessoa;
	}

	private void addAcoes(char opcaoTabela) {
		btnVoltar.addActionListener(e -> trocaTela(new TelaMenu(telaPrincipal)));
		if (opcaoTabela == 'p') {
			btnPesquisar.addActionListener(e -> {
				try {
					if (Validacao.isNome(tfPesquisa.getText(), 0)) {
						modificaTabela(tfPesquisa.getText().trim().toUpperCase());
						mudaLabelNome(lbQtdPesquisa, "Quantidade de registros recuperados: " + registrosRecuperados, 2);
					} else
						Visao.mostraMsgErro("Digite algo valido, nome nao pode ser vazio e deve ser alfabetico.");
				} catch (SQLException e1) {
					Visao.mostraMsgErro("Houve um erro. Voce ser� redirecionado ao menu.");
					trocaTela(new TelaMenu(telaPrincipal));
				}
			});
		}
	}

}
