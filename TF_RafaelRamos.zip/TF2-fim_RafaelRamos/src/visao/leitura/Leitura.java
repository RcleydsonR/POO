package visao.leitura;

import javax.swing.ImageIcon;

import visao.TelaPrincipal;

public class Leitura {

	public static ImageIcon leImagem(String nomeImagem) {
		return new ImageIcon(TelaPrincipal.class.getResource("/visao/img/" + nomeImagem + ".png"));
	}

}
