package controle;

import java.sql.SQLException;

import modelo.dados.Homem;
import modelo.dados.Mulher;
import modelo.dao.PessoaDAO;

public class ControladorCadastro {

	public void cadastrarHomem(String nome, Character saude, Integer idade) throws SQLException, NullPointerException {
		PessoaDAO pesDAO = new PessoaDAO();
		Homem homem = new Homem(nome, saude, idade);
		pesDAO.cadastrar(homem);
	}

	public void cadastrarMulher(String nome, Character saude, Character gestante) throws SQLException, NullPointerException {
		PessoaDAO pesDAO = new PessoaDAO();
		Mulher mulher = new Mulher(nome, saude, gestante);
		pesDAO.cadastrar(mulher);
	}
}
