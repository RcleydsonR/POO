package controle;

import java.sql.SQLException;
import java.util.Collections;

import controle.ordenadores.OrdenaID;
import controle.ordenadores.OrdenaNome;
import modelo.dados.Populacao;
import modelo.dao.PessoaDAO;

public class ControladorLista {
	
	public Populacao getDadosPopulacao() throws SQLException {
		Populacao populacao = new Populacao();
		PessoaDAO pesDao = new PessoaDAO();

		populacao = pesDao.getPopulacao();
		
		Collections.sort(populacao.getPopulacao(), new OrdenaID());

		return populacao;
	}

	public String[] getPessoaPesquisada(int id) throws SQLException {
		PessoaDAO pesDao = new PessoaDAO();
		String[] dadosPessoa = pesDao.getPessoaEspecifica(id);

		return dadosPessoa;
	}

	public Populacao getPopulacaoPesquisada(String nomePesquisado) throws SQLException {
		Populacao populacao = new Populacao();
		Populacao populacaoPesquisada = new Populacao();
		PessoaDAO pesDao = new PessoaDAO();
		
		populacao = pesDao.getPopulacao();

		for (int aux = 0; aux < populacao.getPopulacao().size(); aux++) {
			if (populacao.getPopulacao().get(aux).getNomeCompleto().toString().toUpperCase()
					.contains(nomePesquisado))
				populacaoPesquisada.setPessoa(populacao.getPopulacao().get(aux));
		}
		
		Collections.sort(populacaoPesquisada.getPopulacao(), new OrdenaNome());

		return populacaoPesquisada;
	}
}
