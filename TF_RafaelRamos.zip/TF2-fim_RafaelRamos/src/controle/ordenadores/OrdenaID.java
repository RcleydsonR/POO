package controle.ordenadores;

import java.util.Comparator;

import modelo.dados.Pessoa;

public class OrdenaID implements Comparator<Pessoa>{
	@Override
	public int compare(Pessoa p1, Pessoa p2) {
		return(p1.getNumCadastro().compareTo(p2.getNumCadastro()));
	}

}

